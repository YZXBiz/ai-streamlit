###################################### --- Module Imports --- ######################################
from util import utils
import pandas as pd
from snowflake.connector.pandas_tools import write_pandas
 
###################################### --- Main Function --- ######################################
def generate_space_table(
    query_dict: dict,
    local_path: str = None,
    output_table_name: str = None,
    save_data: bool = True,
    save_type: str = "snowflake",
    save_format: str = "parquet",
    run_date_time: str = None,
):
    """
    Generates a space table for predictive modeling and saves it to the specified location.
 
    This function retrieves raw financials data from Snowflake using an SQL query, processes the data,
    and saves the resulting table either locally or to Snowflake.
 
    Parameters
    ----------
    query_dict : dict
        A dictionary containing the SQL file path with an identifier as the key and the path as the value.
    local_path : str, optional
        The local directory path where the output files will be saved if `save_type` is "local".
    output_table_name : str, optional
        The name of the table or file for storing the financials data.
    save_data : bool, optional
        If True, the function saves the resulting table to the specified storage format. Default is True.
    save_type : str, optional
        Specifies the type of storage for the output files. Can be "local" or "snowflake". Default is "snowflake".
    save_format : str, optional
        The format for saving the output files if `save_type` is "local". Can be "parquet" or "csv". Default is "parquet".
    run_date_time : str, optional
        A timestamp string used when saving the tables to Snowflake.
 
    Returns
    -------
    None or pd.DataFrame
        If `save_data` is True, the function returns None after saving the data. If `save_data` is False,
        it returns the processed DataFrame containing the financials.
 
    Example
    -------
>>> generate_financials_table(
            query_dict={"create_financials_table": "./sql/create_financials_table.sql"},
            local_path="/data/outputs",
            output_table_name="financials_table",
            save_data=True,
            save_type="local",
            save_format="csv",
            run_date_time="2025-01-25 12:00:00"
        )
    """
    # Load sql query
    query_map = utils.load_sql_query(query_dict)
    
    # Execute sql query
    for key, query in query_map.items():
        print(f"Running query: {key}")
        utils.execute_sql_query(query)
 
    # If needed, load the table to Pandas and save locally
    if save_data:
        if save_type == "local":
            # Read data from Snowflake
            query = f"SELECT * FROM {output_table_name};"
            df = utils.read_table(query)
 
            # Save locally in the specified format
            if save_format == "parquet":
                df.to_parquet(f"{local_path}/{output_table_name}.parquet", index=False)
            elif save_format == "csv":
                df.to_csv(f"{local_path}/{output_table_name}.csv", index=False)
            else:
                raise ValueError("Invalid save_format. Must be 'parquet' or 'csv'.")
        elif save_type == "snowflake":
            print(f"Table {output_table_name} created successfully in Snowflake.")
        else:
            raise ValueError("Invalid save_type. Must be 'local' or 'snowflake'.")
 
    print("Space table generation completed successfully.")

