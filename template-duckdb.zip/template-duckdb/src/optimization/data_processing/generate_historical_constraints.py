###################################### --- Module Imports --- ######################################
import pandas as pd
import numpy as np
from util import utils
 
###################################### --- Module Functions --- ######################################
 
def process_pog_size_limits(pog_sizes_df: pd.DataFrame, outlier_limit: float) -> pd.DataFrame:
    
    pog_sizes_df = pog_sizes_df.loc[
        ~((pog_sizes_df["PLANO_CAT_DSC"] == "_HAND & BODY_HAND & BODY") & (pog_sizes_df["FIXTURE_WIDTH_NBR"] == 20))
    ]
 
    pog_sizes_df["within_limit"] = np.where(pog_sizes_df["PCT_STORES"] > outlier_limit, 1, 0)
 
    no_excl = pog_sizes_df.groupby("PLANO_CAT_DSC").agg({"FIXTURE_WIDTH_NBR": ["min", "max"]}).reset_index()
    no_excl.columns = ["PLANO_CAT_DSC", "before_min", "before_max"]
 
    excl = (
        pog_sizes_df[pog_sizes_df["within_limit"] == 1]
        .groupby("PLANO_CAT_DSC")
        .agg({"FIXTURE_WIDTH_NBR": ["min", "max"]})
        .reset_index()
    )
    excl.columns = ["PLANO_CAT_DSC", "after_min", "after_max"]
 
    pog_size_limits = no_excl.merge(excl, on="PLANO_CAT_DSC", how="left")
    pog_size_limits["after_max"] = np.where(
        pog_size_limits["PLANO_CAT_DSC"].str.contains("_SEASONAL_SEASONAL"), 124, pog_size_limits["after_max"]
    )
    pog_size_limits["after_min"] = np.where(
        pog_size_limits["PLANO_CAT_DSC"].str.contains("_SEASONAL_SEASONAL"), 48, pog_size_limits["after_min"]
    )
 
    return pog_size_limits



def prepare_constraints_table(actuals: pd.DataFrame, pog_sizes_actual: pd.DataFrame, pog_size_limits: pd.DataFrame) -> pd.DataFrame:
    """
    Prepares department-level space constraints for each store based on actual POG sizes and limits.
    """
 
    # Merge actuals with store size and min/max limits
    store_size = actuals.groupby("STORE_NBR")["FIXTURE_WIDTH_NBR"].sum().reset_index()
    store_size.rename(columns={"FIXTURE_WIDTH_NBR": "Store_size"}, inplace=True)
 
    actuals["FIXTURE_WIDTH_NBR"] = actuals["FIXTURE_WIDTH_NBR"] / (actuals["FIXTURE_HEIGHT_NBR"] / 60)
 
    constraints_table = actuals[["STORE_NBR", "PLANO_CAT_DSC", "FIXTURE_WIDTH_NBR", "FIXTURE_HEIGHT_NBR"]].drop_duplicates()
    constraints_table = constraints_table.merge(store_size, on="STORE_NBR", how="left")
    constraints_table = constraints_table.merge(
        pog_size_limits[["PLANO_CAT_DSC", "after_min", "after_max"]],
        on="PLANO_CAT_DSC", how="left"
    )
 
    constraints_table.columns = [
        "Store", "Dept", "current_space", "current_height", "Store_size",
        "overall_min_space", "overall_max_space"
    ]
 
    # Flexible constraint ranges
    constraints_table["decrease_based_min"] = np.where(
        constraints_table["current_space"] <= 8, 0,
        np.where(constraints_table["current_space"] <= 20,
                 constraints_table["current_space"] * 0.5,
                 constraints_table["current_space"] * 0.6)
    )
    constraints_table["growth_based_max"] = np.where(
        constraints_table["current_space"] <= 8,
        constraints_table["current_space"] * 2.0,
        np.where(constraints_table["current_space"] <= 20,
                 constraints_table["current_space"] * 1.5,
                 constraints_table["current_space"] * 1.4)
    )
 
    # Special rules for SEASONAL
    constraints_table["decrease_based_min"] = np.where(
        constraints_table["Dept"].str.contains("_SEASONAL_SEASONAL"),
        constraints_table["current_space"] * 0.7,
        constraints_table["decrease_based_min"]
    )
    constraints_table["growth_based_max"] = np.where(
        constraints_table["Dept"].str.contains("_SEASONAL_SEASONAL"),
        constraints_table["current_space"] * 1.3,
        constraints_table["growth_based_max"]
    )
 
    # Clamp constraints within limits
    constraints_table["dept_size_min"] = np.where(
        constraints_table["overall_min_space"] >= constraints_table["decrease_based_min"],
        constraints_table["overall_min_space"],
        constraints_table["decrease_based_min"]
    )
    constraints_table["dept_size_max"] = np.where(
        constraints_table["overall_max_space"] <= constraints_table["growth_based_max"],
        constraints_table["overall_max_space"],
        constraints_table["growth_based_max"]
    )
    constraints_table["dept_size_max"] = np.where(
        constraints_table["dept_size_max"] < constraints_table["dept_size_min"],
        constraints_table["dept_size_min"],
        constraints_table["dept_size_max"]
    )
 
    # Find closest valid POG size for max
    pog_options = pog_sizes_actual[["PLANO_CAT_DSC", "FIXTURE_WIDTH_NBR"]].copy()
    pog_options.columns = ["Dept", "FIXTURE_WIDTH_NBR"]
    constraints_table = constraints_table.merge(pog_options, on="Dept", how="left")
    constraints_table["diff_max"] = constraints_table["FIXTURE_WIDTH_NBR"] - constraints_table["dept_size_max"]
    constraints_table = constraints_table[constraints_table["diff_max"] <= 0]
    constraints_table = constraints_table.sort_values(["Store", "Dept", "diff_max"], ascending=[True, True, False])
    constraints_table = constraints_table.drop_duplicates(subset=["Store", "Dept"], keep="first")
    constraints_table["dept_size_max"] = np.where(
        constraints_table["FIXTURE_WIDTH_NBR"] < constraints_table["dept_size_min"],
        constraints_table["dept_size_min"],
        constraints_table["FIXTURE_WIDTH_NBR"]
    )
 
    constraints_table = constraints_table.drop(["FIXTURE_WIDTH_NBR", "diff_max"], axis=1)
 
    # Find closest valid POG size for min
    constraints_table = constraints_table.merge(pog_options, on="Dept", how="left")
    constraints_table["diff_min"] = constraints_table["FIXTURE_WIDTH_NBR"] - constraints_table["dept_size_min"]
    constraints_table = constraints_table[constraints_table["diff_min"] >= 0]
    constraints_table = constraints_table.sort_values(["Store", "Dept", "diff_min"], ascending=[True, True, True])
    constraints_table = constraints_table.drop_duplicates(subset=["Store", "Dept"], keep="first")
    constraints_table["dept_size_min"] = constraints_table["FIXTURE_WIDTH_NBR"]
    constraints_table = constraints_table.drop(["FIXTURE_WIDTH_NBR", "diff_min"], axis=1)
 
    # Clamp again just in case
    constraints_table["dept_size_min"] = np.where(
        constraints_table["dept_size_min"] >= constraints_table["current_space"],
        constraints_table["current_space"],
        constraints_table["dept_size_min"]
    )
    constraints_table["dept_size_max"] = np.where(
        constraints_table["dept_size_max"] <= constraints_table["current_space"],
        constraints_table["current_space"],
        constraints_table["dept_size_max"]
    )
 
    # Scale based on height
    constraints_table["dept_size_max_scaled"] = constraints_table["dept_size_max"] * (constraints_table["current_height"] / 60)
    constraints_table["dept_size_min_scaled"] = constraints_table["dept_size_min"] * (constraints_table["current_height"] / 60)
    constraints_table["current_space"] = constraints_table["current_space"] * (constraints_table["current_height"] / 60)
 
    final = constraints_table[[
        "Store", "Dept", "Store_size", "current_space", "current_height",
        "dept_size_min_scaled", "dept_size_max_scaled"
    ]].copy()
 
    final.columns = [
        "Store", "Dept", "Store_size", "current_space", "current_height",
        "dept_size_min", "dept_size_max"
    ]
 
    return final



 
###################################### --- Main Function --- ######################################
 
def generate_historical_constraints(
    query_dict: dict,
    outlier_limit: float,
    output_table_global_constraints: str,
    output_table_store_constraints: str,
    save_data: bool,
    run_date_time: str
) -> None:
    """
    Main function to generate historical constraints and write to Snowflake.
 
    Parameters
    ----------
    query_dict : dict
        Dictionary of query labels and file paths.
    outlier_limit : float
        Threshold for removing outlier POG sizes.
    output_table_global_constraints : str
        Full Snowflake table name for store-level constraints.
    output_table_store_constraints : str
        Full Snowflake table name for POG size limits.
    save_data : bool
        Whether to write output tables to Snowflake.
    run_date_time : str
        Timestamp string for logging or versioning.
    """
    # Load SQL files
    queries = utils.load_sql_query(query_dict)
 
    # Run setup query to create intermediate table if required
    if "generate_historical_constraints" in queries:
        print("Running setup SQL...")
        utils.execute_sql_query(queries["generate_historical_constraints"])
 
    # Load data from Snowflake
    actuals_df = utils.read_table(queries["get_macro_predictive_model_data"])
    pog_sizes_df = utils.read_table(queries["get_macro_pog_sizes"])
    
    # Filter actuals to relevant columns
    actuals_filtered = actuals_df[
        ["STORE_NBR", "PLANOGRAM_DSC", "PLANO_CAT_DSC", "FIXTURE_WIDTH_NBR", "TOTAL_SALES", "TOTAL_MARGIN", "FIXTURE_HEIGHT_NBR"]
    ].copy()
    actuals_filtered["PLANO_CAT_DSC"] = "_" + actuals_filtered["PLANO_CAT_DSC"] + "_" + actuals_filtered["PLANOGRAM_DSC"]
    actuals_filtered.drop("PLANOGRAM_DSC", axis=1, inplace=True)
    actuals_filtered.columns = [
        "STORE_NBR", "PLANO_CAT_DSC", "FIXTURE_WIDTH_NBR", "ACTUAL_SALES", "TOTAL_MARGIN", "FIXTURE_HEIGHT_NBR"
    ]
    
    # Filter pog sizes to relevant columns
    pog_sizes_df["PLANO_CAT_DSC"] = pog_sizes_df["PLANO_CAT_DSC"].str.replace("/", "_")
    pog_sizes_df["PLANOGRAM_DSC"] = pog_sizes_df["PLANOGRAM_DSC"].str.replace("/", "_")
    pog_sizes_df["PLANO_CAT_DSC"] = "_" + pog_sizes_df["PLANO_CAT_DSC"] + "_" + pog_sizes_df["PLANOGRAM_DSC"] 
    pog_sizes_df = pog_sizes_df[pog_sizes_df["PLANO_CAT_DSC"].isin(actuals_filtered["PLANO_CAT_DSC"].unique())]
    pog_sizes_df = pog_sizes_df.drop("PLANOGRAM_DSC", axis=1)
 
    # Process limits
    pog_size_limits = process_pog_size_limits(pog_sizes_df, outlier_limit)
 
    
 
    # Build constraints table
    constraints_table = prepare_constraints_table(actuals_filtered, pog_sizes_df, pog_size_limits)
 
    # Save to Snowflake if enabled
    if save_data:
        print("Writing to Snowflake...")
        utils.write_to_snowflake(pog_size_limits, output_table_global_constraints)
        utils.write_to_snowflake(constraints_table, output_table_store_constraints)
 
    print("Historical constraints generation completed.")
    
    
