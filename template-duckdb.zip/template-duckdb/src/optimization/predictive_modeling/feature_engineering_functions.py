import os
import pickle
import joblib
import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Any, Tuple
 
from sklearn.impute import SimpleImputer
from sklearn.model_selection import PredefinedSplit, train_test_split
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
 
# ------------------------ #
# Flag column converter
# ------------------------ #
def convert_flag_columns(df: pd.DataFrame, flag_cols: list) -> pd.DataFrame:
    """
    Converts flag columns with 'Y'/'N' to 1/0.
 
    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    flag_cols : list
        List of column names with Y/N flags
 
    Returns
    -------
    pd.DataFrame
        Modified dataframe with binary columns
    """
    df = df.copy()
    for col in flag_cols:
        df[col] = np.where(df[col] == "Y", 1, 0)
    return df
 
# ------------------------ #
# Store age calculator
# ------------------------ #
def calculate_store_age(df: pd.DataFrame, date_col: str, year_col: str, new_col="STORE_AGE") -> pd.DataFrame:
    """
    Calculates store age in years based on open date and year column.
 
    Parameters
    ----------
    df : pd.DataFrame
    date_col : str
        Column with datetime values
    year_col : str
        Column with year as int
    new_col : str
        Output column name for store age
 
    Returns
    -------
    pd.DataFrame
    """
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df[year_col] = pd.to_numeric(df[year_col], errors="coerce")
    df[new_col] = df.apply(
        lambda row: row[year_col] - row[date_col].year if pd.notnull(row[date_col]) and pd.notnull(row[year_col]) else None,
        axis=1
    )
    return df
 
# ------------------------ #
# Outlier removal by group
# ------------------------ #
def remove_outliers_by_dept(df: pd.DataFrame, columns: list, dept_column="PLANO_CAT_DSC", threshold=1.5) -> pd.DataFrame:
    """
    Removes outliers using IQR method per department.
 
    Parameters
    ----------
    df : pd.DataFrame
    columns : list
        Numeric columns to apply outlier filtering
    dept_column : str
        Department group column
    threshold : float
        IQR multiplier
 
    Returns
    -------
    pd.DataFrame
        Cleaned dataframe
    """
    df_copy = df.copy()
    for column in columns:
        grouped = df_copy.groupby(dept_column)[column]
        Q1 = grouped.quantile(0.25)
        Q3 = grouped.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        df_copy = df_copy[
            (df_copy[column] >= df_copy[dept_column].map(lower_bound)) &
            (df_copy[column] <= df_copy[dept_column].map(upper_bound))
        ]
    return df_copy
 
# ------------------------ #
# Missing value imputer
# ------------------------ #
def impute_values(df: pd.DataFrame, fill_values: dict) -> pd.DataFrame:
    """
    Imputes missing values with constant values.
 
    Parameters
    ----------
    df : pd.DataFrame
    fill_values : dict
        Mapping of column -> default fill value
 
    Returns
    -------
    pd.DataFrame
    """
    for column, value in fill_values.items():
        df[column] = df[column].fillna(value)
    return df
 
# ------------------------ #
# Create custom CV fold
# ------------------------ #
def create_custom_cv_split(data: pd.DataFrame, column: str, validation_values: List[Any]) -> PredefinedSplit:
    """
    Create a PredefinedSplit based on a column's values.
 
    Parameters
    ----------
    data : pd.DataFrame
    column : str
        Column to use for split logic
    validation_values : list
        Values to include in validation set
 
    Returns
    -------
    PredefinedSplit
    """
    train_indices = np.where(data[column].isin(validation_values), 0, -1)
    return PredefinedSplit(train_indices)
 
# ------------------------ #
# Train/test split by store
# ------------------------ #
def partition_stores(store_array, percentages, split_type, seed=None, df=None):
    """
    Partitions store array into train/test sets, optionally stratified.
 
    Parameters
    ----------
    store_array : list
    percentages : dict
        E.g., {'train': 70, 'test': 30}
    split_type : str
        'stratified' or 'random'
    seed : int
    df : pd.DataFrame
        Required for stratified split
 
    Returns
    -------
    Tuple[List, List]
        Train store IDs, Test store IDs
    """
    if sum(percentages.values()) != 100:
        raise ValueError("The percentages must sum to 100.")
 
    if split_type == "stratified":
        unique_stores = df[["STORE_NBR", "ST_CD"]].drop_duplicates()
        state_counts = unique_stores["ST_CD"].value_counts()
        small_states = state_counts[state_counts < 2].index
        small_state_stores = unique_stores[unique_stores["ST_CD"].isin(small_states)]
        remaining_stores = unique_stores[~unique_stores["ST_CD"].isin(small_states)]
 
        train_stores, test_stores = train_test_split(
            remaining_stores,
            test_size=percentages["test"] / 100,
            stratify=remaining_stores["ST_CD"],
            random_state=seed
        )
        train_stores = pd.concat([train_stores, small_state_stores])
        return train_stores["STORE_NBR"], test_stores["STORE_NBR"]
    else:
        np.random.seed(seed)
        np.random.shuffle(store_array)
        train_end = int(len(store_array) * (percentages["train"] / 100))
        return store_array[:train_end], store_array[train_end:]
 
 
# ------------------------ #
# Main preprocessing function
# ------------------------ #
def process_data(
    df: pd.DataFrame,
    dtype_dict: dict,
    impute_dict: dict,
    outlier_cols: list,
    store_open_date_col: str,
    year_col: str,
    flag_cols: list,
    cat_cols: list,
    exclude_cols: list = None,
    ohe_save_path=None,
    train_data=True,
    fitted_ohe=None,
    scale_features=False,
    scaler_save_path=None,
    fitted_scaler=None,
    remove_outliers=None
):
    """
    Runs full data prep pipeline: dtype casting, imputation, outlier removal, feature engineering, OHE, scaling.
 
    Returns
    -------
    pd.DataFrame
        Fully processed dataframe
    """
    df = df.astype(dtype_dict)
    df = impute_values(df, impute_dict)
 
    if remove_outliers:
        df = remove_outliers_by_dept(df, outlier_cols)
 
    df = calculate_store_age(df, store_open_date_col, year_col)
    df = convert_flag_columns(df, flag_cols)
 
    if train_data:
        ohe = OneHotEncoder(sparse=False, handle_unknown="ignore")
        encoded_data = ohe.fit_transform(df[cat_cols])
        encoded_df = pd.DataFrame(encoded_data, columns=ohe.get_feature_names_out(cat_cols))
        if ohe_save_path:
            with open(ohe_save_path, "wb") as file:
                pickle.dump(ohe, file)
    else:
        encoded_data = fitted_ohe.transform(df[cat_cols])
        encoded_df = pd.DataFrame(encoded_data, columns=fitted_ohe.get_feature_names_out(cat_cols))
 
    df = df.drop(columns=cat_cols).reset_index(drop=True)
    df_encoded = pd.concat([df, encoded_df], axis=1)
 
    if scale_features:
        exclude_cols = set(exclude_cols) if exclude_cols else set()
        numeric_cols = set(df_encoded.select_dtypes(include=["number"]).columns)
        scaling_cols = list(numeric_cols - exclude_cols)
 
        if train_data:
            scaler = MinMaxScaler()
            scaled_data = scaler.fit_transform(df_encoded[scaling_cols])
            if scaler_save_path:
                with open(scaler_save_path, "wb") as file:
                    pickle.dump(scaler, file)
        else:
            scaled_data = fitted_scaler.transform(df_encoded[scaling_cols])
 
        for i, col in enumerate(scaling_cols):
            df_encoded[col] = scaled_data[:, i]
 
    return df_encoded
 
# ------------------------ #
# Directory resolver
# ------------------------ #
def find_relevant_directory(existing_model: bool, model_run_id: str = None, base_path: str = None) -> str:
    """
    Returns latest or matching model output directory.
 
    Parameters
    ----------
    existing_model : bool
    model_run_id : str
        Optional: specific run ID
    base_path : str
        Base directory path to look in
 
    Returns
    -------
    str
        Full path to relevant directory
    """
    if existing_model:
        if model_run_id:
            try:
                datetime.strptime(model_run_id, "%Y%m%d")
            except ValueError:
                raise ValueError("model_run_id must be in the format YYYYMMDD")
            return os.path.join(base_path, model_run_id)
 
        if base_path:
            today = datetime.now().strftime("%Y%m%d")
            closest_path, closest_date = None, None
 
            for dir_name in os.listdir(base_path):
                dir_path = os.path.join(base_path, dir_name)
                if os.path.isdir(dir_path):
                    try:
                        dir_date = datetime.strptime(dir_name, "%Y%m%d")
                        if closest_date is None or abs((dir_date - datetime.strptime(today, "%Y%m%d")).days) < abs((closest_date - datetime.strptime(today, "%Y%m%d")).days):
                            closest_date = dir_date
                            closest_path = dir_path
                    except ValueError:
                        continue
 
            if closest_path:
                return closest_path
            else:
                raise ValueError("No valid date directories found in the base path")
        else:
            raise ValueError("base_path must be provided if model_run_id is None")
    return None