import os
import pickle
import numpy as np
import pandas as pd
 
from util import utils
from optimization.predictive_modeling.feature_engineering_functions import process_data
 
    

def process_and_predict_curves(
    base_df: pd.DataFrame,
    space_df: pd.DataFrame,
    fitted_ohe,
    model,
    dept: str,
    segment: str
) -> pd.DataFrame:
    # Replace fixture width
    base_df = base_df.drop("FIXTURE_WIDTH_NBR", axis=1)
    merged_df = base_df.merge(
        space_df,
        left_on=["PLANO_CAT_DSC",'STORE_NBR'],
        right_on=["PLANOGRAM_DSC",'STORE_NBR'],
        how="left",
        validate="m:m"
    ).drop(columns=["PLANOGRAM_DSC"])
 
    if merged_df.empty:
        return pd.DataFrame()
    processed = process_data(
        df=merged_df,
        dtype_dict={"TOTAL_SALES": "float", "YEAR": "int"},
        impute_dict={"TOTAL_SALES": 0},
        outlier_cols=["TOTAL_SALES"],
        store_open_date_col="OPEN_DATE",
        year_col="YEAR",
        flag_cols=[],
        cat_cols=["PLANO_CAT_DSC"],
        exclude_cols=["STORE_NBR", "TOTAL_SALES"],
        fitted_ohe=fitted_ohe,
        train_data=False,
        scale_features=False,
        remove_outliers=False
    )
 
    X_test = processed.drop(columns=["TOTAL_SALES", "STORE_NBR", "OPEN_DATE", "ST_CD"])
    X_test = X_test[model.feature_names_in_]
    
    
    preds_log = model.predict(X_test)
    preds = np.expm1(preds_log)
    processed["PREDICTED_SALES"] = preds
 
    encoded_columns = fitted_ohe.get_feature_names_out()
    plano_cat_columns = [col for col in encoded_columns if "PLANO_CAT_DSC" in col]
    processed["PLANO_CAT_DSC"] = processed[plano_cat_columns].idxmax(axis=1).str.replace("PLANO_CAT_DSC_", "")
    processed["PLANO_CAT_DSC"] = "_" + dept + "_" + processed["PLANO_CAT_DSC"]
 
    processed["segment"] = segment
    processed["dept_name"] = dept
 
    processed["MAX_PREDICTED_SALES"] = processed.groupby(
        ["STORE_NBR", "PLANO_CAT_DSC"]
    )["PREDICTED_SALES"].transform("max")
 
    processed["PREDICTED_SALES_RELATIVE_TO_MAX"] = (
        processed["PREDICTED_SALES"] / processed["MAX_PREDICTED_SALES"]
    ).fillna(0)
 
    return processed
 
    

def generate_productivity_curves_data(
    departments: list,
    model_output_path: str,
    one_hot_encoder_file_name: str,
    model_file_name: str,
    model_type: str,
    run_date_time: str,
    year_to_predict: int = 2024,
):
    all_predictions = []
    
    departments = utils.read_table(
                f"""
                select distinct PLANOGRAM_DSC from DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
                where planogram_nbr in (9711, 9115, 9070, 9536, 9137, 9605, 9171, 9608, 9623, 9600, 9302, 9300, 9617, 9601, 9378, 
                9895, 9380, 9136, 9728, 9061, 9030, 9040, 9060, 9035, 9576, 9242, 9041, 9140,
                9544, 9210, 9640, 9285, 9281, 9240, 9260, 9280, 9918, 9523, 9542, 9062, 9370, 9255, 7700, 9145, 9700, 9090, 9615, 
                9770, 9150, 9470, 9570, 9236, 9616, 9211, 9425, 9631, 9690,
                9080, 9428, 9400, 9410, 9475, 9403, 9270, 9020, 9822, 9360, 9571, 9367, 9398, 9401, 9683, 9531, 9751, 9406, 9680, 
                3920, 9224, 9200, 9340, 9010, 9330, 9620, 9350, 9500, 9582, 9584, 9569, 9232)
                ;
                """
            )['PLANOGRAM_DSC'].tolist()
 
    for dept in departments:
        print(f"Processing department: {dept}")
 
        for segment, condition in [("low_sales", "<= 3500000"), ("high_sales", "> 3500000")]:
            print(f"  Segment: {segment}")
 
            # Load base data (same as model training)
            base_query = f"""
                SELECT * FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table_full
                WHERE PLANOGRAM_DSC = '{dept}' AND TOTAL_FS_SALES {condition}
            """
            raw_data = utils.read_table(base_query)
 
            drop_cols = [
                'PLANO_MDSE_GRP_DSC', 'FIXTURE_HEIGHT_NBR', 'PLANOGRAM_NBR', 'TOTAL_SOLD_QTY', 'TOTAL_COST',
                'TOTAL_MARGIN', 'PLANO_CAT_DSC', 'WHITE_PCT', 'BLACK_PCT', 'ASIAN_PCT', 'OTHER_RACE_PCT',
                'HISP_PCT', 'RETAIL_SQ_FT', 'TOTAL_SQ_FT', 'ACQ_NAME', 'YEARS_SINCE_REMODL',
                'YEARS_SINCE_ACQ', 'TOTAL_FS_SALES'
            ]
            raw_data = raw_data.drop(columns=drop_cols, errors="ignore")
            raw_data.dropna(subset=["ST_CD"], inplace=True)
            raw_data.fillna(0, inplace=True)
            raw_data = raw_data.rename(columns={"PLANOGRAM_DSC": "PLANO_CAT_DSC"})
            base_df = raw_data[raw_data["YEAR"] == year_to_predict].copy()
            
            if raw_data.empty or raw_data.loc[raw_data["YEAR"] == 2024].shape[0] < 100:
                print(f"Skipping {dept} [{segment}] due to insufficient data.")
                continue
                
            
 
            # Load space options
            options_query = f"""
                SELECT PLANOGRAM_DSC, store_nbr, FIXTURE_WIDTH_NBR
                FROM DL_FSCA_SLFSRV.TWA07.MACRO_SPACE_OPTIONS_WITH_STORE_DATA
                WHERE "segment" = '{segment}' AND PLANOGRAM_DSC = '{dept}'
            """
            space_df = utils.read_table(options_query)
 
            if space_df.empty:
                print(f"Skipping {dept} [{segment}] — no space options.")
                continue
 
            # Load OHE + Model
            ohe_path = os.path.join(model_output_path, f"{dept}_{segment}_ohe.pkl")
            model_path = os.path.join(model_output_path, f"{dept}_{segment}_model.pkl")
            fitted_ohe = pickle.load(open(ohe_path, "rb"))
            model = pickle.load(open(model_path, "rb"))
            
 
            preds_df = process_and_predict_curves(
                base_df, space_df, fitted_ohe, model, dept, segment
            )
 
            if preds_df.empty:
                continue
 
            all_predictions.append(preds_df)
 
    final_df = pd.concat(all_predictions, ignore_index=True)
 
    utils.write_to_snowflake(
        final_df[
            [
                "STORE_NBR",
                "PLANO_CAT_DSC",
                "FIXTURE_WIDTH_NBR",
                "PREDICTED_SALES",
                "MAX_PREDICTED_SALES",
                "PREDICTED_SALES_RELATIVE_TO_MAX",
                "segment",
                "dept_name",
            ]
        ],
        "DL_FSCA_SLFSRV.TWA07.MACRO_PRODUCTIVITY_CURVES_DATA"
    )