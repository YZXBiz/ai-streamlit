import os
import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
 
from typing import Dict, Any
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from xgboost import XGBRegressor, DMatrix
 
def get_combined_predictions(
    model, 
    X_train, y_train, 
    X_test, y_test, 
    train_store_nbr, test_store_nbr, 
    ohe_file_name,
    y_pred_col="PREDICTED_SALES"
):
    train_preds_log = model.predict(X_train)
    test_preds_log = model.predict(X_test)
 
    train_preds = np.expm1(train_preds_log)
    test_preds = np.expm1(test_preds_log)
    y_train = np.expm1(y_train)
    y_test = np.expm1(y_test)
 
    train_df = X_train.copy()
    train_df["STORE_NBR"] = train_store_nbr.values
    train_df["ACTUAL_SALES"] = y_train.values
    train_df[y_pred_col] = train_preds
    train_df["DATASET"] = "train"
 
    test_df = X_test.copy()
    test_df["STORE_NBR"] = test_store_nbr.values
    test_df["ACTUAL_SALES"] = y_test.values
    test_df[y_pred_col] = test_preds
    test_df["DATASET"] = "test"
 
    combined_df = pd.concat([train_df, test_df], axis=0).reset_index(drop=True)
 
    ohe_file = os.path.join(os.getcwd(), ohe_file_name)
    with open(ohe_file, "rb") as f:
        ohe = pickle.load(f)
 
    encoded_columns = ohe.get_feature_names_out()
    plano_cat_columns = [col for col in encoded_columns if "PLANO_CAT_DSC" in col]
 
    combined_df["PLANO_CAT_DSC"] = combined_df[plano_cat_columns].idxmax(axis=1).str.replace("PLANO_CAT_DSC_", "")
    combined_df = combined_df.drop(columns=plano_cat_columns)
 
    return combined_df
 

    
    
def model_eval(df, y_actual_col, y_pred_col, dataset_col, dept_col):
    results = []
    for dataset in df[dataset_col].unique():
        subset = df[df[dataset_col] == dataset]
        n, p = len(subset), len(subset.columns) - 4
        weights = subset[y_actual_col]
        weighted_r2 = 1 - sum(weights * (subset[y_actual_col] - subset[y_pred_col])**2) / sum(weights * (subset[y_actual_col] - weights.mean())**2)
        adj_r2 = 1 - ((1 - weighted_r2) * (n - 1) / (n - p - 1))
        weighted_mape = (abs((subset[y_actual_col] - subset[y_pred_col]) / subset[y_actual_col]) * weights).sum() / weights.sum()
        weighted_mpe = ((subset[y_pred_col] - subset[y_actual_col]) / subset[y_actual_col] * weights).sum() / weights.sum()
        total_sales = subset[y_actual_col].sum()
        store_count = subset["STORE_NBR"].nunique() if "STORE_NBR" in subset.columns else None
 
        results.append({
            "DATASET": dataset,
            "R2": weighted_r2,
            "Adjusted R2": adj_r2,
            "MAPE": weighted_mape,
            "MPE": weighted_mpe,
            "Total_Sales": total_sales,
            "Store_Count": store_count
        })
 
    return pd.DataFrame(results)
 
        
 
    return pd.DataFrame(results)
 
def plot_feature_importance(model, feature_names, file_name, top_n=30, include_feature="FIXTURE_WIDTH_NBR"):
    importance = model.feature_importances_
    feature_importances = {}
    for feature, score in zip(feature_names, importance):
        if feature.startswith("ST_CD"):
            feature_importances["STATE"] = feature_importances.get("STATE", 0) + score
        else:
            feature_importances[feature] = score
 
    if include_feature in feature_names:
        feature_importances[include_feature] = importance[np.where(feature_names == include_feature)[0][0]]
 
    sorted_features = sorted(feature_importances.items(), key=lambda x: x[1], reverse=True)
    top_features = sorted_features[:top_n]
    if include_feature not in [f[0] for f in top_features]:
        for feature, score in sorted_features:
            if feature == include_feature:
                top_features.append((feature, score))
                break
        top_features = sorted(top_features, key=lambda x: x[1], reverse=True)
 
    feature_names_final, feature_importance_final = zip(*top_features)
 
    plt.figure(figsize=(10, 6))
    plt.barh(range(len(feature_importance_final)), feature_importance_final, align="center")
    plt.yticks(range(len(feature_importance_final)), feature_names_final)
    plt.gca().invert_yaxis()
    plt.xlabel("Feature Importance")
    plt.title("Top Feature Importance")
    plt.tight_layout()
 
    file_path = os.path.join(os.getcwd(), file_name)
    plt.savefig(file_path)
    plt.close()
    print(f"Feature importance plot saved at {file_path}")

def plot_weighted_mape_and_sales(metrics_df, file_name):
    filtered_df = metrics_df[(metrics_df["Level"] == "PLANO_CAT_DSC") & (metrics_df["DATASET"] == "test")]
 
    categories = filtered_df["PLANO_CAT_DSC"]
    mape = filtered_df["MAPE"]
    mpe = filtered_df["MPE"]
    total_sales = filtered_df["Total_Sales"]
 
    x = np.arange(len(categories))
    bar_width = 0.35
 
    fig, ax1 = plt.subplots(figsize=(12, 6))
    ax1.bar(x - bar_width / 2, mape, bar_width, label="MAPE", color="red", alpha=0.7)
    ax1.bar(x + bar_width / 2, mpe, bar_width, label="MPE", color="blue", alpha=0.7)
    ax1.set_xlabel("PLANO_CAT_DSC")
    ax1.set_ylabel("MAPE and MPE")
    ax1.set_xticks(x)
    ax1.set_xticklabels(categories, rotation=45)
    ax1.legend(loc="upper left")
 
    ax2 = ax1.twinx()
    ax2.plot(x, total_sales, color="gray", marker="o", linestyle="-", linewidth=2, label="Total Sales ($)")
    ax2.set_ylabel("Total Sales ($)")
    ax2.tick_params(axis="y", labelcolor="gray")
    ax2.legend(loc="upper right")
 
    plt.title("Model performance by Planogram")
    plt.tight_layout()
    file_path = os.path.join(os.getcwd(), file_name)
    plt.savefig(file_path)
    plt.close()
    
    
    
    
def plot_actual_vs_predicted_all_departments(results_df, y_actual_col, y_pred_col, dept_col, file_name):
    for dept in results_df[dept_col].unique():
        dept_data = results_df[results_df[dept_col] == dept]
        sanitized_dept = dept.replace("\\", "_").replace("/", "_").replace(" ", "_")
        plt.figure(figsize=(8, 6))
        plt.scatter(dept_data[y_actual_col], dept_data[y_pred_col], alpha=0.6)
        plt.plot(
            [dept_data[y_actual_col].min(), dept_data[y_actual_col].max()],
            [dept_data[y_actual_col].min(), dept_data[y_actual_col].max()],
            color="red", linestyle="--"
        )
        plt.title(f"Actual vs Predicted Sales - {dept}")
        plt.xlabel("Actual Sales")
        plt.ylabel("Predicted Sales")
        plt.tight_layout()
        file_path = os.path.join(os.getcwd(), file_name)
        plt.savefig(file_path)
        plt.close()
        print(f"Plot saved for {dept} at {file_path}")