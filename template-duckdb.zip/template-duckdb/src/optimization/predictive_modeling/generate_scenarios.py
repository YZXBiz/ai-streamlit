import pandas as pd
import numpy as np
from util import utils
 
def adjust_allocated_space(df: pd.DataFrame, threshold: float = 0.3) -> pd.DataFrame:
    df_copy = df.copy()
    mask = (df_copy["MAX_FIXTURE_WIDTH_NBR"] - df_copy["MIN_FIXTURE_WIDTH_NBR"]) < threshold
    df_copy.loc[mask, "MIN_FIXTURE_WIDTH_NBR"] *= 0.8
    df_copy.loc[mask, "MAX_FIXTURE_WIDTH_NBR"] *= 1.2
    return df_copy
 
def generate_space_options(df: pd.DataFrame, num_options: int, dept_name: str, segment: str) -> pd.DataFrame:
    result = []
    df["MIN_FIXTURE_WIDTH_NBR"] = df["MIN_FIXTURE_WIDTH_NBR"].astype("float64")
    df["MAX_FIXTURE_WIDTH_NBR"] = df["MAX_FIXTURE_WIDTH_NBR"].astype("float64")
 
    grouped = df.groupby(["PLANOGRAM_DSC", "PLANO_CAT_DSC"])
 
    for (pog, cat), group in grouped:
        min_space = group["MIN_FIXTURE_WIDTH_NBR"].min()
        max_space = group["MAX_FIXTURE_WIDTH_NBR"].max()
        space_options = np.linspace(min_space, max_space, num=num_options).astype(int)
 
        for space in space_options:
            result.append({
                "dept_name": dept_name,
                "segment": segment,
                "PLANOGRAM_DSC": pog,
                "PLANO_CAT_DSC": cat,
                "FIXTURE_WIDTH_NBR": space
            })
 
    return pd.DataFrame(result)
 
def process_dept_scenarios(df: pd.DataFrame, dept_name: str, segment: str, num_options: int) -> pd.DataFrame:
    total_stores = df["STORE_NBR"].nunique()
    store_threshold = total_stores * 0.001
    valid_fixture_widths = (
        df.groupby("FIXTURE_WIDTH_NBR")["STORE_NBR"]
        .nunique()
        .pipe(lambda x: x[x >= store_threshold])
        .index
    )
    df = df[df["FIXTURE_WIDTH_NBR"].isin(valid_fixture_widths)]
 
    size_table = (
        df.groupby(["PLANOGRAM_DSC", "PLANO_CAT_DSC"])
        .agg(
            MIN_FIXTURE_WIDTH_NBR=("FIXTURE_WIDTH_NBR", "min"),
            MAX_FIXTURE_WIDTH_NBR=("FIXTURE_WIDTH_NBR", "max")
        )
        .reset_index()
    )
 
    adjusted = adjust_allocated_space(size_table)
    space_options = generate_space_options(adjusted, num_options, dept_name, segment)
 
    return space_options
 
def generate_scenarios_for_prod_curves(
    departments: list,
    num_options: int,
    run_date_time: str
):
    all_options = []
    all_joined = []
    
    departments = utils.read_table(
                    f"""
                    select distinct PLANOGRAM_DSC from DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
                    where planogram_nbr in (9711, 9115, 9070, 9536, 9137, 9605, 9171, 9608, 9623, 9600, 9302, 9300, 9617, 9601, 9378, 
                    9895, 9380, 9136, 9728, 9061, 9030, 9040, 9060, 9035, 9576, 9242, 9041, 9140,
                    9544, 9210, 9640, 9285, 9281, 9240, 9260, 9280, 9918, 9523, 9542, 9062, 9370, 9255, 7700, 9145, 9700, 9090, 9615, 
                    9770, 9150, 9470, 9570, 9236, 9616, 9211, 9425, 9631, 9690,
                    9080, 9428, 9400, 9410, 9475, 9403, 9270, 9020, 9822, 9360, 9571, 9367, 9398, 9401, 9683, 9531, 9751, 9406, 9680, 
                    3920, 9224, 9200, 9340, 9010, 9330, 9620, 9350, 9500, 9582, 9584, 9569, 9232)
                    ;
                    """
                )['PLANOGRAM_DSC'].tolist()
 
    for dept in departments:
        print(f"Generating scenarios for department: {dept}")
 
        for segment, condition in [("low_sales", "<= 3500000"), ("high_sales", "> 3500000")]:
            print(f"  Segment: {segment}")
 
            query = f"""
                SELECT STORE_NBR, FIXTURE_WIDTH_NBR, YEAR, PLANOGRAM_DSC, PLANO_CAT_DSC, TOTAL_FS_SALES
                FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table_full
                WHERE PLANOGRAM_DSC = '{dept}'
                AND TOTAL_FS_SALES {condition}
            """
            df = utils.read_table(query)
 
            if df.empty:
                continue
 
            options = process_dept_scenarios(df, dept, segment, num_options)
 
            unique_stores = df[["STORE_NBR"]].drop_duplicates()
            options["key"] = 1
            unique_stores["key"] = 1
 
            cross_joined = options.merge(unique_stores, on="key").drop("key", axis=1)
 
            all_options.append(options)
            all_joined.append(cross_joined)
 
    final_options = pd.concat(all_options, ignore_index=True)
    final_joined = pd.concat(all_joined, ignore_index=True)
 
    utils.write_to_snowflake(final_options, "DL_FSCA_SLFSRV.TWA07.MACRO_SPACE_OPTIONS")
    utils.write_to_snowflake(final_joined, "DL_FSCA_SLFSRV.TWA07.MACRO_SPACE_OPTIONS_WITH_STORE_DATA")