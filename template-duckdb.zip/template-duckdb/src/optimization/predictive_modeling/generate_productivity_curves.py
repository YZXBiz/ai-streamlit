import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from matplotlib.backends.backend_pdf import PdfPages
import sympy as sp
import seaborn as sns
from util import utils
 
def log_func(x, a, b):
    return a * np.log(x) + b
 
def exp_decay_func(x, a, b):
    return a * (1 - np.exp(-b * x))
 
def fit_curves(df, fit_function="exp_decay", polynomial_order=2):
    results = []
 
    filtered = df.groupby(["STORE_NBR", "PLANO_CAT_DSC"]).filter(
        lambda x: x["PREDICTED_SALES"].nunique() > 1
    )
 
    if filtered.empty:
        return pd.DataFrame()
 
    for dept in filtered["PLANO_CAT_DSC"].unique():
        dept_df = filtered[filtered["PLANO_CAT_DSC"] == dept]
        for store in dept_df["STORE_NBR"].unique():
            store_data = dept_df[dept_df["STORE_NBR"] == store]
 
            if store_data.empty:
                continue
 
            x = store_data["FIXTURE_WIDTH_NBR"].values
            y = store_data["PREDICTED_SALES"].values
            margin_rate = store_data["MARGIN_RATE"].iloc[0] if "MARGIN_RATE" in store_data.columns else 1.0
 
            try:
                if fit_function == "log":
                    if np.all(x > 0):
                        popt, _ = curve_fit(log_func, x, y, maxfev=5000)
                        fitted_sales_function = f"{popt[0]} * log(x) + {popt[1]}"
                        fitted_margin_function = f"{popt[0]*margin_rate} * log(x) + {popt[1]*margin_rate}"
                    else:
                        continue
 
                elif fit_function == "poly":
                    coeffs = np.polyfit(x, y, polynomial_order)
                    fitted_sales_function = " + ".join(
                        [f"{coeff:.6f}*x**{i}" for i, coeff in enumerate(coeffs[::-1])]
                    )
                    fitted_margin_function = " + ".join(
                        [f"{(coeff*margin_rate):.6f}*x**{i}" for i, coeff in enumerate(coeffs[::-1])]
                    )
 
                elif fit_function == "exp_decay":
                    if np.all(x > 0):
                        initial_guess = (max(y), 1.0 / (max(x) - min(x)))
                        popt, _ = curve_fit(exp_decay_func, x, y, p0=initial_guess, maxfev=5000)
                        fitted_sales_function = f"{popt[0]} * (1 - exp(-{popt[1]} * x))"
                        fitted_margin_function = f"{popt[0]*margin_rate} * (1 - exp(-{popt[1]} * x))"
                    else:
                        continue
                else:
                    raise ValueError("fit_function must be 'log', 'poly', or 'exp_decay'")
 
                results.append({
                    "STORE_NBR": store,
                    "PLANO_CAT_DSC": dept,
                    "FITTED_SALES_FUNCTION": fitted_sales_function,
                    "FITTED_MARGIN_FUNCTION": fitted_margin_function
                })
 
            except Exception as e:
                print(f"Fit failed for Store {store}, Dept {dept}: {e}")
                continue
 
    return pd.DataFrame(results)
 
def combined_plot_by_dept(raw_data, fitted_data, total_allocated_space_col, predicted_sales_col, dept_name_col, store_no_col):
    x = sp.symbols('x')
    unique_depts = raw_data[dept_name_col].unique()
 
    for dept in unique_depts:
        print(f'Department: {dept}')
        dept_raw_data = raw_data[raw_data[dept_name_col] == dept]
        dept_fitted_data = fitted_data[fitted_data[dept_name_col] == dept]
 
        plt.figure(figsize=(10, 6))
        sns.scatterplot(
            data=dept_raw_data,
            x=total_allocated_space_col,
            y=predicted_sales_col,
            hue=store_no_col,
            palette='viridis',
            s=100,
            alpha=0.8,
            edgecolor="w",
            linewidth=1.5
        )
 
        for store_no in dept_fitted_data[store_no_col].unique():
            store_fitted_data = dept_fitted_data[dept_fitted_data[store_no_col] == store_no]
            fitted_function_str = store_fitted_data['FITTED_SALES_FUNCTION'].iloc[0]
 
            try:
                fitted_function_expr = sp.sympify(fitted_function_str)
                fitted_function = sp.lambdify(x, fitted_function_expr, modules=['numpy'])
                x_values = dept_raw_data[dept_raw_data[store_no_col] == store_no][total_allocated_space_col].values
                y_values = fitted_function(x_values)
                plt.plot(x_values, y_values, linestyle='--')
            except Exception as e:
                print(f"Plotting failed for store {store_no}, dept {dept}: {e}")
 
        plt.title(f'Scatter and Fitted Function Plot for {dept}', fontsize=16)
        plt.xlabel('Total Allocated Space', fontsize=14)
        plt.ylabel('Sales', fontsize=14)
        plt.grid(False)
        plt.tight_layout()
        plt.show()
 
 
def generate_productivity_curves(
    departments: list,
    run_date_time: str,
    fit_function: str = "exp_decay",
    polynomial_order: int = 2,
    plot_output_dir: str = "./curve_plots",
    save_data: bool = True,
    output_table_name: str = "MACRO_PRODUCTIVITY_CURVE_FUNCTIONS"
):
    all_results = []

    departments = utils.read_table(
                    f"""
                    select distinct PLANOGRAM_DSC from DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
                    where planogram_nbr in (9711, 9115, 9070, 9536, 9137, 9605, 9171, 9608, 9623, 9600, 9302, 9300, 9617, 9601, 9378, 
                    9895, 9380, 9136, 9728, 9061, 9030, 9040, 9060, 9035, 9576, 9242, 9041, 9140,
                    9544, 9210, 9640, 9285, 9281, 9240, 9260, 9280, 9918, 9523, 9542, 9062, 9370, 9255, 7700, 9145, 9700, 9090, 9615, 
                    9770, 9150, 9470, 9570, 9236, 9616, 9211, 9425, 9631, 9690,
                    9080, 9428, 9400, 9410, 9475, 9403, 9270, 9020, 9822, 9360, 9571, 9367, 9398, 9401, 9683, 9531, 9751, 9406, 9680, 
                    3920, 9224, 9200, 9340, 9010, 9330, 9620, 9350, 9500, 9582, 9584, 9569, 9232)
                    ;
                    """
                )['PLANOGRAM_DSC'].tolist()
 
    for dept in departments:
        print(f"\n=== Dept: {dept} ===")
 
        for segment in ["low_sales", "high_sales"]:
            print(f"Segment: {segment}")
 
            pred_query = f"""
                SELECT STORE_NBR, PLANO_CAT_DSC, FIXTURE_WIDTH_NBR, PREDICTED_SALES,
                       MAX_PREDICTED_SALES, PREDICTED_SALES_RELATIVE_TO_MAX
                FROM DL_FSCA_SLFSRV.TWA07.MACRO_PRODUCTIVITY_CURVES_DATA
                WHERE "dept_name" = '{dept}' AND "segment" = '{segment}'
            """
            pred_df = utils.read_table(pred_query)
 
            margin_query = f"""
                SELECT STORE_NBR, PLANOGRAM_DSC, PLANO_CAT_DSC, TOTAL_SALES, TOTAL_MARGIN, YEAR
                FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table_full
                WHERE PLANOGRAM_DSC = '{dept}' AND YEAR = 2024
            """
            margin_df = utils.read_table(margin_query)
 
            if pred_df.empty or margin_df.empty:
                continue
 
            margin_df["PLANO_CAT_DSC"] = "_" + margin_df["PLANO_CAT_DSC"] + "_" + margin_df["PLANOGRAM_DSC"]
            margin_df["MARGIN_RATE"] = margin_df["TOTAL_MARGIN"] / margin_df["TOTAL_SALES"]
            margin_df = margin_df[["STORE_NBR", "PLANO_CAT_DSC", "MARGIN_RATE"]]
 
            merged = pred_df.merge(margin_df, on=["STORE_NBR", "PLANO_CAT_DSC"], how="left")
        
 
            curves_df = fit_curves(merged, fit_function=fit_function, polynomial_order=polynomial_order)
 
            if curves_df.empty:
                continue
 
            curves_df["segment"] = segment
            curves_df["dept_name"] = dept
            all_results.append(curves_df)
 
            os.makedirs(plot_output_dir, exist_ok=True)
            with PdfPages(f"{plot_output_dir}/{dept}_{segment}_curves.pdf") as pdf:
                original_show = plt.show
                plt.show = lambda: pdf.savefig(plt.gcf()) or plt.close()
 
                combined_plot_by_dept(
                    raw_data=merged,
                    fitted_data=curves_df,
                    total_allocated_space_col='FIXTURE_WIDTH_NBR',
                    predicted_sales_col='PREDICTED_SALES',
                    dept_name_col='PLANO_CAT_DSC',
                    store_no_col='STORE_NBR'
                )
 
                plt.show = original_show  # Restore
 
    final_df = pd.concat(all_results, ignore_index=True)
 
    if save_data and not final_df.empty:
        utils.write_to_snowflake(
            final_df,
            f"DL_FSCA_SLFSRV.TWA07.{output_table_name}"
        )