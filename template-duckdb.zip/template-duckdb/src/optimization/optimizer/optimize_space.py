import pandas as pd
import numpy as np
import time
from util import utils
from optimization.optimizer.optimization_functions import optimize_all_stores
 
def prepare_combined_curve_functions(
    low_sales_df: pd.DataFrame,
    high_sales_df: pd.DataFrame,
    seasonal_curves_path: str,
    actuals: pd.DataFrame
) -> pd.DataFrame:
    low_df = low_sales_df.copy()
    high_df = high_sales_df.copy()
 
    high_stores = high_df["STORE_NBR"].unique()
    low_df = low_df[~low_df["STORE_NBR"].isin(high_stores)]
 
    combined_model = pd.concat([low_df, high_df], ignore_index=True)
    # combined_model["PLANO_CAT_DSC"] = "_" + combined_model["PLANO_CAT_DSC"] + "_" + combined_model["PLANOGRAM_DSC"]
    combined_model = combined_model[["STORE_NBR", "PLANO_CAT_DSC", "FITTED_SALES_FUNCTION", "FITTED_MARGIN_FUNCTION"]]
    combined_model.columns = ["Store", "Dept", "FITTED_SALES_FUNCTION", "FITTED_MARGIN_FUNCTION"]
    combined_model["sales_weight"] = 1
    combined_model["margin_weight"] = 1
    combined_model["type"] = "Model generated"
    combined_model = combined_model.loc[combined_model['Dept']!='_SEASONAL_SEASONAL']

 
    seasonal_df = pd.read_csv(seasonal_curves_path)
    seasonal_df = seasonal_df[seasonal_df["PLANOGRAM_DSC"] == "SEASONAL"]
    seasonal_stores = actuals[actuals["PLANO_CAT_DSC"] == "_SEASONAL_SEASONAL"]["STORE_NBR"].unique()
    seasonal_df = seasonal_df[seasonal_df["STORE_NBR"].isin(seasonal_stores)]
 
    seasonal_df["Dept"] = "_" + seasonal_df["PLANO_CAT_DSC"] + "_" + seasonal_df["PLANOGRAM_DSC"]
    seasonal_df["Store"] = seasonal_df["STORE_NBR"]
    seasonal_df["sales_weight"] = 1
    seasonal_df["margin_weight"] = 1
    seasonal_df["type"] = "Model generated"
    seasonal_df = seasonal_df[["Store", "Dept", "FITTED_SALES_FUNCTION", "FITTED_MARGIN_FUNCTION", "sales_weight", "margin_weight", "type"]]
 
    combined = pd.concat([combined_model, seasonal_df], ignore_index=True)
 
    # Fill missing curve combos with backup linear functions
    actual_keys = actuals[["STORE_NBR", "PLANO_CAT_DSC"]].drop_duplicates()
    curve_keys = combined[["Store", "Dept"]].drop_duplicates().rename(columns={"Store": "STORE_NBR", "Dept": "PLANO_CAT_DSC"})
    missing = actual_keys.merge(curve_keys, on=["STORE_NBR", "PLANO_CAT_DSC"], how="left", indicator=True)
    missing = missing[missing["_merge"] == "left_only"].drop(columns=["_merge"])
 
    backup = actuals.merge(missing, on=["STORE_NBR", "PLANO_CAT_DSC"], how="inner")
    backup["sales_productivity"] = backup["ACTUAL_SALES"] / backup["FIXTURE_WIDTH_NBR"]
    backup["margin_productivity"] = backup["TOTAL_MARGIN"] / backup["FIXTURE_WIDTH_NBR"]
 
    backup["FITTED_SALES_FUNCTION"] = backup["sales_productivity"].round(2).astype(str) + " * x"
    backup["FITTED_MARGIN_FUNCTION"] = backup["margin_productivity"].round(2).astype(str) + " * x"
    backup["Store"] = backup["STORE_NBR"]
    backup["Dept"] = backup["PLANO_CAT_DSC"]
    backup["sales_weight"] = 1
    backup["margin_weight"] = 1
    backup["type"] = "Backup"
 
    backup_df = backup[["Store", "Dept", "FITTED_SALES_FUNCTION", "FITTED_MARGIN_FUNCTION", "sales_weight", "margin_weight", "type"]]
 
    final_curves = pd.concat([combined, backup_df], ignore_index=True)
    return final_curves
 
def optimize_space(run_date_time: str, stores_in_scope: list = None):
    print("Loading data...")
 
    # Load constraints
    constraints_df = utils.read_table("SELECT * FROM DL_FSCA_SLFSRV.TWA07.MACRO_GLOBAL_STORE_CONSTRAINTS")
 
    # Load actuals for past sales info
    sales_query = """
        SELECT STORE_NBR, PLANO_CAT_DSC, PLANOGRAM_DSC, TOTAL_SALES, TOTAL_MARGIN, FIXTURE_WIDTH_NBR, FIXTURE_HEIGHT_NBR, YEAR
        FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
        WHERE YEAR = 2024
    """
    sales_df = utils.read_table(sales_query)
    sales_df["PLANO_CAT_DSC"] = "_" + sales_df["PLANO_CAT_DSC"] + "_" + sales_df["PLANOGRAM_DSC"]
 
    actuals = sales_df.rename(columns={
        "STORE_NBR": "STORE_NBR",
        "PLANO_CAT_DSC": "PLANO_CAT_DSC",
        "FIXTURE_WIDTH_NBR": "FIXTURE_WIDTH_NBR",
        "FIXTURE_HEIGHT_NBR": "FIXTURE_HEIGHT_NBR",
        "TOTAL_SALES": "ACTUAL_SALES",
        "TOTAL_MARGIN": "TOTAL_MARGIN"
    })
 
    actuals = actuals[["STORE_NBR", "PLANO_CAT_DSC", "FIXTURE_WIDTH_NBR", "ACTUAL_SALES", "TOTAL_MARGIN", "FIXTURE_HEIGHT_NBR"]]
    past_sales_info = actuals.rename(columns={
        "STORE_NBR": "Store",
        "PLANO_CAT_DSC": "Dept",
        "FIXTURE_WIDTH_NBR": "LY_SPACE",
        "FIXTURE_HEIGHT_NBR": "LY_HEIGHT",
        "ACTUAL_SALES": "LY_SALES",
        "TOTAL_MARGIN": "LY_MARGIN"
    })
     
        
    low_sales_curves = """
    select STORE_NBR,PLANO_CAT_DSC,FITTED_SALES_FUNCTION,FITTED_MARGIN_FUNCTION,"dept_name"
    from DL_FSCA_SLFSRV.TWA07.MACRO_PRODUCTIVITY_CURVES_FUNCTIONS
    where "segment"='low_sales'
    """
    low_sales_curves_df =utils.read_table(low_sales_curves)    
    
    
    high_sales_curves = """
    select STORE_NBR,PLANO_CAT_DSC,FITTED_SALES_FUNCTION,FITTED_MARGIN_FUNCTION,"dept_name"
    from DL_FSCA_SLFSRV.TWA07.MACRO_PRODUCTIVITY_CURVES_FUNCTIONS
    where "segment"='high_sales'
    """
    high_sales_curves_df =utils.read_table(high_sales_curves) 

    
    # Prepare curve functions
    curves_df = prepare_combined_curve_functions(
        low_sales_df=low_sales_curves_df,
        high_sales_df=high_sales_curves_df,
        seasonal_curves_path="/home/jovyan/Analysis/Data/Seasonal curves.csv",
        actuals=actuals
    )
 
    # Load POG sizes
    pog_query = "SELECT * FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_pog_sizes"
    pog_df = utils.read_table(pog_query)
    pog_df["PLANO_CAT_DSC"] = pog_df["PLANO_CAT_DSC"].str.replace("/", "_")
    pog_df["PLANOGRAM_DSC"] = pog_df["PLANOGRAM_DSC"].str.replace("/", "_")
    pog_df["Dept"] = "_" + pog_df["PLANO_CAT_DSC"] + "_" + pog_df["PLANOGRAM_DSC"]
    pog_sizes = pog_df[["Dept", "FIXTURE_WIDTH_NBR", "STORE_COUNT", "TOTAL_STORES", "PCT_STORES"]]
 
    if stores_in_scope is None:
        stores_in_scope = [6912]
 
    print(f"Running optimization for {len(stores_in_scope)} stores...")
    start_time = time.time()
     
    log_df, result_df, steps_df = optimize_all_stores(
        stores_in_scope,
        constraints_table=constraints_df,
        objective_functions=curves_df,
        past_sales_information_df=past_sales_info,
        pog_sizes=pog_sizes
    )
 
    print("Saving results...")
    utils.write_to_snowflake(result_df, "DL_FSCA_SLFSRV.TWA07.MACRO_OPTIMIZED_SPACE_ALLOCATION", run_date_time)
    print(f"Done in {(time.time() - start_time):.2f} seconds")