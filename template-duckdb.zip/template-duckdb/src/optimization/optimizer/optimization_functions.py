import pandas as pd
import numpy as np
import os
import sympy as sp
 
def evaluate_weighted_function(df, column_to_evaluate, new_column_name, sales_weight=1, margin_weight=1):
    x = sp.symbols('x')
 
    def evaluate(row):
        try:
            sales_function = sp.sympify(row['FITTED_SALES_FUNCTION'])
            margin_function = sp.sympify(row['FITTED_MARGIN_FUNCTION'])
            sales_value = float(sales_function.subs(x, row[column_to_evaluate]))
            margin_value = float(margin_function.subs(x, row[column_to_evaluate]))
            return (sales_weight * sales_value) + (margin_weight * margin_value)
        except Exception:
            return np.nan
 
    df[new_column_name] = df.apply(evaluate, axis=1)
    return df
 
def remove_infeasible_options(options_df, unallotted_space):
    return options_df[
        (options_df['proposed_space'] <= options_df['dept_size_max']) &
        (options_df['proposed_space'] > options_df['dept_allotted_space']) &
        (options_df['Increment_size'] <= unallotted_space)
    ]
 
def optimize_single_store(store, constraints_table, objective_functions, past_sales_information_df, pog_sizes):
    store_constraints = constraints_table[constraints_table['Store'] == store].copy()
    store_objectives = objective_functions[objective_functions['Store'] == store].copy()
 
    store_data = store_constraints.merge(
        store_objectives[['Store', 'Dept', 'FITTED_SALES_FUNCTION', 'FITTED_MARGIN_FUNCTION', 'sales_weight', 'margin_weight']],
        on=['Store', 'Dept'], how='inner'
    )
 
    store_data['dept_allotted_space'] = np.where(store_data['Dept'] == '_SEASONAL_SEASONAL', 0.0001, 0)
    total_store_size = store_data['Store_size'].iloc[0]
    unallotted_space = total_store_size - store_data['dept_allotted_space'].sum()
 
    log_data = []
    opt_steps_details = pd.DataFrame()
    round_count = 0
    apply_boost = 1
    boost_rate = 1.2
 
    while unallotted_space > 0:
        round_count += 1
 
        def get_next_increment(row):
            dept_pog_sizes = pog_sizes[pog_sizes['Dept'] == row['Dept']].copy()
            dept_pog_sizes['SCALED_FIXTURE_WIDTH'] = dept_pog_sizes['FIXTURE_WIDTH_NBR'] * (row['current_height'] / 60)
            scaled_sizes = dept_pog_sizes['SCALED_FIXTURE_WIDTH'].sort_values().unique()
            current_space = row['dept_allotted_space']
            min_space = row['dept_size_min']
            scaled_sizes = scaled_sizes[scaled_sizes >= min_space]
            next_sizes = scaled_sizes[scaled_sizes > current_space]
            return next_sizes[0] - current_space if len(next_sizes) > 0 else 0
 
        store_data['Increment_size'] = store_data.apply(get_next_increment, axis=1)
        store_data['Increment_size'] = store_data['Increment_size'].apply(lambda x: min(x, unallotted_space) if x > 0 else 0)
 
        if store_data.empty:
            break
 
        store_data = evaluate_weighted_function(store_data, 'dept_allotted_space', 'current_objective', 1, 1)
        store_data['proposed_space'] = store_data['dept_allotted_space'] + store_data['Increment_size']
        store_data = evaluate_weighted_function(store_data, 'proposed_space', 'proposed_objective', 1, 1)
 
        store_data['incremental_objective'] = np.where(
            store_data['Increment_size'] == 0,
            0,
            (store_data['proposed_objective'] - store_data['current_objective']) / store_data['Increment_size']
        )
 
        if apply_boost == 1:
            store_data['incremental_objective'] = np.where(
                (store_data['dept_allotted_space'] == 0) & (store_data['Increment_size'] > 0),
                store_data['incremental_objective'] * boost_rate,
                store_data['incremental_objective']
            )
 
        opt_steps_details_temp = store_data.copy()
        opt_steps_details_temp['round'] = round_count
        opt_steps_details = pd.concat([opt_steps_details, opt_steps_details_temp], ignore_index=True)
 
        feasible_options = store_data[
            (store_data['proposed_space'] <= store_data['dept_size_max']) &
            (store_data['dept_allotted_space'] + store_data['Increment_size'] <= total_store_size) &
            (store_data['Increment_size'] != 0)
        ]
 
        if feasible_options.empty:
            break
 
        best_row = feasible_options.loc[feasible_options['incremental_objective'].idxmax()]
        allocated_increment = best_row['Increment_size']
        store_data.loc[store_data['Dept'] == best_row['Dept'], 'dept_allotted_space'] += allocated_increment
        unallotted_space -= allocated_increment
 
        log_data.append({
            'Round': round_count,
            'Store': store,
            'Dept': best_row['Dept'],
            'Incremental Objective': best_row['incremental_objective'],
            'Increment Size': allocated_increment,
            'Unallotted Space': unallotted_space,
            'Proposed Space': best_row['proposed_space'],
            'Current Objective': best_row['current_objective'],
            'Proposed Objective': best_row['proposed_objective'],
            'Cumulative Allotted Space': store_data['dept_allotted_space'].sum(),
        })
 
    store_data = store_data.merge(past_sales_information_df, on=["Store", "Dept"], how="left")
    store_data = evaluate_weighted_function(store_data, 'dept_allotted_space', 'forecasted_objective', 1, 1)
    store_data = evaluate_weighted_function(store_data, 'dept_allotted_space', 'forecasted_sales', 1, 0)
    store_data = evaluate_weighted_function(store_data, 'dept_allotted_space', 'forecasted_margin', 0, 1)
    store_data = evaluate_weighted_function(store_data, 'LY_SPACE', 'LY_forecasted_objective', 1, 1)
    store_data = evaluate_weighted_function(store_data, 'LY_SPACE', 'LY_forecasted_sales', 1, 0)
    store_data = evaluate_weighted_function(store_data, 'LY_SPACE', 'LY_forecasted_margin', 0, 1)
 
    store_data["incremental_sales"] = store_data["forecasted_sales"] - store_data["LY_forecasted_sales"]
    store_data["incremental_margin"] = store_data["forecasted_margin"] - store_data["LY_forecasted_margin"]
 
    drop_cols = ['sales_weight', 'margin_weight', 'Increment_size', 'current_objective', 'proposed_space',
                 'proposed_objective', 'incremental_objective', 'forecasted_objective',
                 'LY_forecasted_objective', 'LY_SPACE', 'LY_HEIGHT']
    existing_drop_cols = [col for col in drop_cols if col in store_data.columns]
    store_data.drop(existing_drop_cols, axis=1, inplace=True)
 
    return pd.DataFrame(log_data), store_data, opt_steps_details
 
def optimize_all_stores(stores_in_scope, constraints_table, objective_functions, past_sales_information_df, pog_sizes):
    all_logs = []
    all_results = []
    all_opt_steps_details = []
 
    for store in stores_in_scope:
        log_df, result_df, steps_df = optimize_single_store(
            store, constraints_table, objective_functions, past_sales_information_df, pog_sizes
        )
        all_logs.append(log_df)
        all_results.append(result_df)
        all_opt_steps_details.append(steps_df)
 
    return pd.concat(all_logs), pd.concat(all_results), pd.concat(all_opt_steps_details)
 
def append_to_file(df, file_path):
    if not os.path.exists(file_path):
        df.to_csv(file_path, index=False)
    else:
        df.to_csv(file_path, mode='a', header=False, index=False)