import pandas as pd
import numpy as np
from util import utils
 
def stratified_sample(
    df: pd.DataFrame,
    num_buckets: int,
    frac: float
) -> pd.DataFrame:
    """
    Stratified sampling by sales buckets and ST_CD, with bucket and percentile labels.
 
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with STORE_NBR, ST_CD, and TOTAL_SALES.
    num_buckets : int
        Number of buckets to split sales into.
    frac : float
        Sample fraction (e.g., 0.06 for 6%).
 
    Returns
    -------
    pd.DataFrame
        Sampled DataFrame with SALES_BUCKET and PERCENTILE_LABEL.
    """
    # Step 1: Create sales buckets
    df["SALES_BUCKET_IDX"], bins = pd.qcut(
        df["TOTAL_SALES"],
        q=num_buckets,
        labels=False,
        retbins=True,
        duplicates="drop"
    )
 
    # Step 2: Add readable bucket and percentile labels
    bucket_labels = [f"[{bins[i]:.2f}, {bins[i+1]:.2f})" for i in range(len(bins) - 1)]
    percentiles = np.linspace(0, 100, len(bins))
    percentile_labels = [f"{int(percentiles[i])}-{int(percentiles[i+1])}%" for i in range(len(percentiles)-1)]
 
    df["SALES_BUCKET"] = df["SALES_BUCKET_IDX"].apply(lambda x: bucket_labels[int(x)])
    df["PERCENTILE_LABEL"] = df["SALES_BUCKET_IDX"].apply(lambda x: percentile_labels[int(x)])
    df.drop(columns=["SALES_BUCKET_IDX"], inplace=True)
 
    # Step 3: Sample
    sampled_df = df.groupby(["ST_CD", "SALES_BUCKET"], group_keys=False).apply(
        lambda x: x.sample(frac=frac, random_state=42)
    ).reset_index(drop=True)
 
    return sampled_df
 
def generate_store_sample(
    sample_percent: float,
    num_buckets: int,
    run_date_time: str
):
    # Step 1: Load store-level sales
    sales_query = """
        WITH store_item_monthly_sales AS (
            SELECT a.*,
                   b.facility_typ_dsc, b.state_cd, b.active_store_ind, b.retail_sq_ft,
                   c.category_dsc, c.subcategory_dsc, c.sku_dsc
            FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_monthly_financials a 
            LEFT JOIN CORE_FSSC.CURATED_LOCATION.STORE b USING (store_nbr)
            LEFT JOIN CORE_FSSC.CURATED_PRODUCT.SKU c USING (sku_nbr)
            WHERE state_cd NOT IN ('HI', 'PR')
              AND facility_typ_dsc = 'Retail CVS/pharmacy'
              AND active_store_ind = 'Y'
              AND category_dsc != 'COMPANY DEFAULT'
              AND total_sales > 0
              AND retail_sq_ft > 0
        )
        SELECT STORE_NBR, state_cd AS ST_CD, SUM(TOTAL_SALES) AS TOTAL_SALES
        FROM store_item_monthly_sales
        WHERE load_year_month BETWEEN '2024-01' AND '2024-52'
        GROUP BY STORE_NBR, ST_CD;
    """
    sales_df = utils.read_table(sales_query)
 
    # Step 2: Sample
    sample_frac = sample_percent / 100
    sampled_df = stratified_sample(sales_df, num_buckets, sample_frac)
 
    # Step 3: Save to Snowflake
    utils.write_to_snowflake(
        sampled_df,
        "DL_FSCA_SLFSRV.TWA07.MACRO_SAMPLE_STORES",
        run_date_time
    )
 
    return sampled_df