create
or replace table DL_FSCA_SLFSRV.TWA07.MACRO_POG_DETAILS as
with
    -- Select the historical planogram data 
    -- Using version char to identify planograms that have height in inches compared to feet in general
    -- Filter out planograms which are not in production/dummy
    -- Filter out planograms which dont have any stores , skus, width associated with them
    -- Filter our non-production planograms 
    pog_data as (
        select
            planogram_nbr,
            planogram_version_id,
            planogram_version_dsc,
            fixture_width_nbr,
            fixture_height_nbr,
            planogram_dsc,
            planogram_type_cd,
            section_width_id,
            sku_cnt_nbr,
            store_cnt_nbr,
            load_dt,
            max(
                case
                    when version_characteristics_1_dsc = 'INC' then 1
                    when version_characteristics_2_dsc = 'INC' then 1
                    when version_characteristics_3_dsc = 'INC' then 1
                    when version_characteristics_4_dsc = 'INC' then 1
                    when version_characteristics_5_dsc = 'INC' then 1
                    else 0
                end
            ) as inches_indicator
        from
            CORE_FSSC.CURATED_VISUAL.PLANOGRAM_VERSION_HISTORY
        where
            1 = 1
            and planogram_production_ind = 'Y'
            and store_cnt_nbr > 0
            and sku_cnt_nbr > 0
            and planogram_type_cd not in ('P', 'Q', 'L', 'N', 'O', 'M', 'S', 'T')
            and fixture_width_nbr > 0
        group by ALL
        order by
            planogram_dsc,
            planogram_version_dsc,
            load_dt
    ),
    -- Convert planograms sizes into feet and join with planogram hierarchy table (shared by Clint)
    pog_clean as (
        select
            a.planogram_nbr,
            a.planogram_version_id,
            planogram_dsc,
            planogram_version_dsc,
            planogram_type_cd,
            section_width_id,
            load_dt,
            sku_cnt_nbr,
            store_cnt_nbr,
            case
                when inches_indicator = 1 then fixture_width_nbr / 12
                else fixture_width_nbr
            end as fixture_width_nbr,
            fixture_height_nbr,
            plano_cat_dsc,
            plano_mdse_grp_dsc
        from
            pog_data a
            left join DL_FSCA_SLFSRV.TWA07.c830557_POG_CAT_DSC b using (planogram_nbr)
        order by
            planogram_dsc,
            planogram_version_dsc,
            load_dt
    ),
    -- Normalize planogram width based on height (base height is 60 ft)
    pog_clean_adj as (
        select
            planogram_nbr,
            planogram_version_id,
            planogram_dsc,
            planogram_version_dsc,
            planogram_type_cd,
            section_width_id,
            plano_cat_dsc,
            plano_mdse_grp_dsc,
            load_dt,
            sku_cnt_nbr,
            store_cnt_nbr,
            fixture_height_nbr,
            case
                when planogram_dsc = 'BEVERAGE COOLER' then fixture_width_nbr * (floor(fixture_height_nbr / 24)) * (fixture_height_nbr / 60)
                else fixture_width_nbr * (fixture_height_nbr / 60)
            end as fixture_width_nbr
        from
            pog_clean
        order by
            planogram_dsc,
            planogram_version_dsc,
            load_dt
    )
select
    *
from
    pog_clean_adj;