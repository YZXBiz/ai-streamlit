create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_POG_DETAILS as 

with 

-- Join planogram base table with planogram, items table 
pog_items as (
select a.*, b.sku_nbr, b.horizontal_facings_nbr, b.vertical_facings_nbr
from DL_FSCA_SLFSRV.TWA07.MACRO_POG_DETAILS a 
left join CORE_FSSC.CURATED_VISUAL.PLANOGRAM_SKU_HISTORY b using (planogram_nbr, planogram_version_id, load_dt)
order by planogram_dsc, planogram_version_dsc, load_dt 
),

-- Join planogram, items  table with planogram, store table 
pog_store_items as (
select b.store_nbr, a.planogram_nbr, a.planogram_version_id, a.sku_nbr, a.load_dt, 
a.plano_mdse_grp_dsc, a.plano_cat_dsc, a.planogram_dsc, a.planogram_version_dsc, a.planogram_type_cd, a.section_width_id,
a.sku_cnt_nbr as pog_sku_cnt_nbr, a.store_cnt_nbr as pog_store_cnt_nbr,
a.fixture_height_nbr, a.fixture_width_nbr,
a.horizontal_facings_nbr, a.vertical_facings_nbr
from pog_items a
inner join CORE_FSSC.CURATED_VISUAL.PLANOGRAM_STORE_HISTORY b using (planogram_nbr, planogram_version_id, load_dt)
order by store_nbr, planogram_dsc, planogram_version_dsc, load_dt
),


-- Aggregate planogram, store, items table at monthly level 
pog_store_items_monthly as (
select to_char(load_dt, 'YYYY-MM') as load_year_month,
store_nbr, planogram_nbr, planogram_version_id, sku_nbr, 
plano_mdse_grp_dsc, plano_cat_dsc, planogram_dsc, planogram_version_dsc, planogram_type_cd,section_width_id,
max(fixture_height_nbr) as fixture_height_nbr, max(fixture_width_nbr) as fixture_width_nbr,
max(horizontal_facings_nbr) as horizontal_facings_nbr, max(vertical_facings_nbr) as vertical_facings_nbr
from pog_store_items
group by 1,2,3,4,5,6,7,8,9,10,11
order by store_nbr, planogram_nbr,sku_nbr,load_year_month
),

-- Select unique planogram, store, items table, year-month - dropping duplicates 
pog_store_items_monthly_adj as (
select * from 
(select load_year_month,
store_nbr, planogram_nbr, planogram_version_id, sku_nbr, 
plano_mdse_grp_dsc, plano_cat_dsc, planogram_dsc, planogram_version_dsc, planogram_type_cd,section_width_id,
 fixture_height_nbr,  fixture_width_nbr,
 horizontal_facings_nbr,  vertical_facings_nbr,
 row_number() over(partition by store_nbr, planogram_nbr, sku_nbr, load_year_month order by planogram_version_dsc) as rnk
from pog_store_items_monthly
order by store_nbr, planogram_nbr,sku_nbr,load_year_month )
where rnk=1  
)

select * from pog_store_items_monthly_adj;