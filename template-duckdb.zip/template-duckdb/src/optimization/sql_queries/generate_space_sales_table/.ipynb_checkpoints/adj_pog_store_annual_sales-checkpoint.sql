create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_YEARLY_POG_SALES_DETAILS2 as 

with seasonal_sales as (
select 
cast(left(load_year_month, 4) as int)  as load_year,
store_nbr,
sum(TOTAL_SOLD_QTY) as TOTAL_SOLD_QTY, 
sum(total_sales) as total_sales, 
sum(total_cost) as total_cost, 
sum(total_margin) as total_margin
from DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_FINANCIALS a 
left join CORE_FSSC.CURATED_LOCATION.STORE b using (store_nbr)
left join CORE_FSSC.CURATED_PRODUCT.SKU c using (sku_nbr)
where 1=1
and state_cd NOT IN ('HI', 'PR')
and facility_typ_dsc  in  ('Retail CVS/pharmacy')
and active_store_ind='Y'
and category_nbr in (30,81,82,83)
and total_sales >0
and retail_sq_ft>0
and load_year_month>='2024-01' and load_year_month<='2024-52'
group by 1,2),

seasonal_pog as (

select a.load_year, a.store_nbr, 3920 as planogram_nbr,
'SEASONAL' as planogram_dsc, 
'SEASONAL' as plano_cat_dsc,
'GENERAL MERCHANDISE' as plano_mdse_grp_dsc,
fix_height_inc as fixture_height_nbr,
fixt_wtd_size as fixture_width_nbr,
TOTAL_SOLD_QTY, 
total_sales, 
total_cost, 
total_margin
from seasonal_sales a 
inner join DL_FSCA_SLFSRV.TWA07.C830557_SEASONAL b using (store_nbr)
where b.plano_nbr ='3920-001'),

remaining_pogs as (
select load_year,store_nbr,  
 planogram_nbr_group as planogram_nbr, planogram_dsc_group as planogram_dsc,
plano_cat_dsc, plano_mdse_grp_dsc, 
max(fixture_height_nbr) as fixture_height_nbr, 
sum(fixture_width_nbr) as fixture_width_nbr, 
sum(TOTAL_SOLD_QTY) as TOTAL_SOLD_QTY, 
sum(total_sales) as total_sales, 
sum(total_cost) as total_cost, 
sum(total_margin) as total_margin
from  DL_FSCA_SLFSRV.TWA07.MACRO_YEARLY_POG_SALES_DETAILS
where planogram_nbr != 3920
group by 1,2,3,4,5,6)

select * from remaining_pogs
union
select * from seasonal_pog;
