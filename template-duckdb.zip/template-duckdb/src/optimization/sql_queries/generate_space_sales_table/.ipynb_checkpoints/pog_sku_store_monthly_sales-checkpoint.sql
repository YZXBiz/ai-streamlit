create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_POG_SALES_DETAILS as 

with 

store_item_monthly_sales as (
select a.*,
b.facility_typ_dsc, b.state_cd, b.active_store_ind, b.retail_sq_ft,
c.category_dsc, c.subcategory_dsc, c.sku_dsc
from DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_FINANCIALS a 
left join CORE_FSSC.CURATED_LOCATION.STORE b using (store_nbr)
left join CORE_FSSC.CURATED_PRODUCT.SKU c using (sku_nbr)
where 1=1
and state_cd NOT IN ('HI', 'PR')
and facility_typ_dsc  in  ('Retail CVS/pharmacy')
and active_store_ind='Y'
and category_dsc != 'COMPANY DEFAULT'
and total_sales >0
and retail_sq_ft>0
),


pog_store_items_monthly_sales as (
select * from  DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_POG_DETAILS a 
inner join store_item_monthly_sales b using (store_nbr, sku_nbr, load_year_month)
),



double_homed_items as (
select store_nbr, sku_nbr, load_year_month,
count(distinct planogram_nbr, planogram_version_id) as pog_counts,
sum(HORIZONTAL_FACINGS_NBR* VERTICAL_FACINGS_NBR) as total_facings
from pog_store_items_monthly_sales
group by 1,2,3
having pog_counts>1
),

pog_store_items_monthly_sales_adj as (
select 
STORE_NBR,SKU_NBR,LOAD_YEAR_MONTH,PLANOGRAM_NBR,PLANOGRAM_VERSION_ID,
PLANO_MDSE_GRP_DSC,PLANO_CAT_DSC,PLANOGRAM_DSC,PLANOGRAM_VERSION_DSC,PLANOGRAM_TYPE_CD,
FIXTURE_HEIGHT_NBR,FIXTURE_WIDTH_NBR,
HORIZONTAL_FACINGS_NBR,	VERTICAL_FACINGS_NBR,
FACILITY_TYP_DSC,STATE_CD,RETAIL_SQ_FT,CATEGORY_DSC,SUBCATEGORY_DSC,SKU_DSC,
case when pog_counts is null then total_sales else total_sales*((HORIZONTAL_FACINGS_NBR* VERTICAL_FACINGS_NBR)/total_facings) end as total_sales,
case when pog_counts is null then TOTAL_SOLD_QTY else TOTAL_SOLD_QTY*((HORIZONTAL_FACINGS_NBR* VERTICAL_FACINGS_NBR)/total_facings) end as TOTAL_SOLD_QTY,
case when pog_counts is null then total_cost else total_cost*((HORIZONTAL_FACINGS_NBR* VERTICAL_FACINGS_NBR)/total_facings) end as total_cost,
case when pog_counts is null then total_margin else total_margin*((HORIZONTAL_FACINGS_NBR* VERTICAL_FACINGS_NBR)/total_facings) end as total_margin
from pog_store_items_monthly_sales a
left join double_homed_items b using (store_nbr, sku_nbr, load_year_month)
)




select * from pog_store_items_monthly_sales_adj;