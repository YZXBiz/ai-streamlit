create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_YEARLY_POG_SALES_DETAILS as 

select 
cast(left(load_year_month, 4) as int)  as load_year,
a.STORE_NBR,a.PLANOGRAM_NBR,
a.PLANO_MDSE_GRP_DSC,a.PLANO_CAT_DSC,a.PLANOGRAM_DSC,
b.planogram_dsc_group, b.planogram_nbr_group,
a.STATE_CD,a.RETAIL_SQ_FT,
avg(FIXTURE_HEIGHT_NBR) as FIXTURE_HEIGHT_NBR,
avg(FIXTURE_WIDTH_NBR) as FIXTURE_WIDTH_NBR,
sum(total_sales) as total_sales,
sum(TOTAL_SOLD_QTY) as TOTAL_SOLD_QTY,
sum(total_cost) as total_cost,
sum(total_margin) as total_margin
from DL_FSCA_SLFSRV.TWA07.c830557_macro_monthly_pog_lvl_sales_table a 
inner join DL_FSCA_SLFSRV.TWA07.MACRO_POGS_TO_SCALE b using (planogram_nbr)
where load_year_month >='2023-01' and load_year_month<='2024-12'
group by 1,2,3,4,5,6,7,8,9,10;