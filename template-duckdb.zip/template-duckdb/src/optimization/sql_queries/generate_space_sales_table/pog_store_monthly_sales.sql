create
or replace table DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_POG_SALES_DETAILS as
select
    STORE_NBR,
    LOAD_YEAR_MONTH,
    PLANOGRAM_NBR,
    PLANOGRAM_VERSION_ID,
    PLANO_MDSE_GRP_DSC,
    PLANO_CAT_DSC,
    PLANOGRAM_DSC,
    PLANOGRAM_VERSION_DSC,
    PLANOGRAM_TYPE_CD,
    FIXTURE_HEIGHT_NBR,
    FIXTURE_WIDTH_NBR,
    STATE_CD,
    RETAIL_SQ_FT,
    sum(total_sales) as total_sales,
    sum(TOTAL_SOLD_QTY) as TOTAL_SOLD_QTY,
    sum(total_cost) as total_cost,
    sum(total_margin) as total_margin
from
    DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_POG_SALES_DETAILS
group by ALL