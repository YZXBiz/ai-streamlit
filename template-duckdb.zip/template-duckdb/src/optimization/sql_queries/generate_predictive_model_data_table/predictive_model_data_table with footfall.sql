CREATE OR REPLACE TABLE DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table_full AS
WITH fs_sales_filtered AS (
    SELECT 
        sales.STORE_NBR,
        sales.TOTAL_SALES as TOTAL_FS_SALES,
        size.TOTAL_WIDTH as TOTAL_FS_WIDTH
    FROM DL_FSCA_SLFSRV.TWA07.MACRO_STORE_TOTAL_SALES sales
    INNER JOIN DL_FSCA_SLFSRV.TWA07.MACRO_STORE_TOTAL_POG_SIZE size
        ON sales.STORE_NBR = size.STORE_NBR
      AND size.TOTAL_WIDTH > 900
),
 
footfall_unpivoted AS (
    SELECT 
        "store_id" AS STORE_NBR,
        "city" as city,
        "state_name" as state_name,
        "zipcode" as zipcode,
        LEFT(column_name, 4) AS YEAR,
        value AS footfall
    FROM DL_FSCA_SLFSRV.TWA07.MACRO_STORE_WEEKLY_FOOTFALL
    UNPIVOT (
        value FOR column_name IN (
            "2023_01_02", "2023_01_09", "2023_01_16", "2023_01_23", "2023_01_30",
            "2023_02_06", "2023_02_13", "2023_02_20", "2023_02_27",
            "2023_03_06", "2023_03_13", "2023_03_20", "2023_03_27",
            "2023_04_03", "2023_04_10", "2023_04_17", "2023_04_24",
            "2023_05_01", "2023_05_08", "2023_05_15", "2023_05_22", "2023_05_29",
            "2023_06_05", "2023_06_12", "2023_06_19", "2023_06_26",
            "2023_07_03", "2023_07_10", "2023_07_17", "2023_07_24", "2023_07_31",
            "2023_08_07", "2023_08_14", "2023_08_21", "2023_08_28",
            "2023_09_04", "2023_09_11", "2023_09_18", "2023_09_25",
            "2023_10_02", "2023_10_09", "2023_10_16", "2023_10_23", "2023_10_30",
            "2023_11_06", "2023_11_13", "2023_11_20", "2023_11_27",
            "2023_12_04", "2023_12_11", "2023_12_18", "2023_12_25",
            "2024_01_01", "2024_01_08", "2024_01_15", "2024_01_22", "2024_01_29",
            "2024_02_05", "2024_02_12", "2024_02_19", "2024_02_26",
            "2024_03_04", "2024_03_11", "2024_03_18", "2024_03_25",
            "2024_04_01", "2024_04_08", "2024_04_15", "2024_04_22", "2024_04_29",
            "2024_05_06", "2024_05_13", "2024_05_20", "2024_05_27",
            "2024_06_03", "2024_06_10", "2024_06_17", "2024_06_24",
            "2024_07_01", "2024_07_08", "2024_07_15", "2024_07_22", "2024_07_29",
            "2024_08_05", "2024_08_12", "2024_08_19", "2024_08_26",
            "2024_09_02", "2024_09_09", "2024_09_16", "2024_09_23", "2024_09_30",
            "2024_10_07", "2024_10_14", "2024_10_21", "2024_10_28",
            "2024_11_04", "2024_11_11", "2024_11_18", "2024_11_25",
            "2024_12_02", "2024_12_09", "2024_12_16", "2024_12_23", "2024_12_30"
        )
    )
),
 
store_footfall_yearly AS (
    SELECT 
        STORE_NBR,
        city,
        state_name,
        zipcode,
        YEAR::INT AS YEAR,
        SUM(footfall) AS total_footfall
    FROM footfall_unpivoted
    GROUP BY STORE_NBR, city, state_name, zipcode, YEAR
),
 
city_footfall_avg AS (
    SELECT 
        city,
        YEAR,
        AVG(total_footfall) AS city_avg_footfall
    FROM store_footfall_yearly
    GROUP BY city, YEAR
),
 
year_footfall_avg AS (
    SELECT 
        YEAR,
        AVG(total_footfall) AS year_avg_footfall
    FROM store_footfall_yearly
    GROUP BY YEAR
),
 
model_data_base AS (
    SELECT *
    FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
    WHERE PLANO_CAT_DSC IS NOT NULL
)

-- select * from store_footfall_yearly 
-- where store_nbr =5149
-- limit 20;

-- select * from city_footfall_avg 
-- where city in ('Abbeville','Temple Terrace')
-- limit 20;
 
SELECT
    m.*,
    s.TOTAL_FS_SALES,
    COALESCE( cf.city_avg_footfall, yf.year_avg_footfall) AS footfall
FROM model_data_base m
inner JOIN fs_sales_filtered s ON m.STORE_NBR = s.STORE_NBR
LEFT JOIN store_footfall_yearly f ON m.STORE_NBR = f.STORE_NBR AND m.YEAR = f.YEAR
LEFT JOIN city_footfall_avg cf ON f.city = cf.city AND m.YEAR = cf.YEAR
LEFT JOIN year_footfall_avg yf ON m.YEAR = yf.YEAR;