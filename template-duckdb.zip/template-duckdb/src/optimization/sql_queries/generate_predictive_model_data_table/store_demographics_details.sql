create or replace table DL_FSCA_SLFSRV.TWA07.c830557_localization_store_demographics_master_table as 
select *
from CORE_FS.CURATED_PRODUCT.STORE_DEMOGRAPHIC ;
