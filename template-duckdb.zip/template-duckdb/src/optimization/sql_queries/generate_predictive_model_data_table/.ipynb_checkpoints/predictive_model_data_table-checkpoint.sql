create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_PREDICTIVE_MODEL_TABLE as  

with 
store_details as (
select a.str_nbr, rx_open_dt ,remodl_dt, acquired_dt, 
case when acq_name is null then 'No acquisition' else acq_name end as acq_name,
case when acq_name is null then 0 else 1 end as acq_flag,
retail_sq_ft, total_sq_ft, 
case when retail_sq_ft> total_sq_ft then retail_sq_ft else total_sq_ft end  as store_sq_ft,
c.msa_name from CORE_FSSC.CURATED_LOCATION.STORE_MASTER a
inner join
(select distinct store_nbr from DL_FSCA_SLFSRV.TWA07.MACRO_YEARLY_POG_SALES_DETAILS2) b
on a.str_nbr =b.store_nbr
left join DL_FSCA_SLFSRV.TWA07.c830557_localization_store_demographics_master_table c on a.str_nbr=c.str_nbr
),

market_details as (
select msa_name, min(rx_open_dt) as first_store_launch_in_geo_mkt_dt
from store_details
group by 1
),

store_details_full as (
select a.str_nbr, a.rx_open_dt, a.remodl_dt, a.msa_name, a.retail_sq_ft, a.total_sq_ft,a.store_sq_ft, a.acq_name,a.acq_flag,
case when remodl_dt is not null then datediff('day', remodl_dt, current_date)/365.25
else  datediff('day', rx_open_dt, current_date)/365.25 end as years_since_remodl,
case when first_store_launch_in_geo_mkt_dt is not null then   datediff('day', first_store_launch_in_geo_mkt_dt, current_date)/365.25 
else datediff('day', rx_open_dt, current_date)/365.25 end as years_since_first_launch_in_geomkt,
case when acquired_dt is not null then datediff('day', acquired_dt, current_date)/365.25
else  datediff('day', rx_open_dt, current_date)/365.25 end as years_since_acq
from store_details a
left join market_details b using (msa_name)
)

select 
load_year as YEAR, a.STORE_NBR,	PLANOGRAM_NBR,	
replace(PLANO_CAT_DSC,'/','_') as PLANO_CAT_DSC,
replace(PLANOGRAM_DSC,'/','_') as PLANOGRAM_DSC,
PLANO_MDSE_GRP_DSC,	
FIXTURE_HEIGHT_NBR,
FIXTURE_WIDTH_NBR,TOTAL_SOLD_QTY,TOTAL_SALES,TOTAL_COST,TOTAL_MARGIN,
 rx_open_dt as OPEN_DATE, years_since_remodl,years_since_first_launch_in_geomkt, years_since_acq, acq_flag,acq_name, ST_CD , retail_sq_ft, total_sq_ft,store_sq_ft, POP_1_MILE_CNT, DAYNITE_RATIO_FCTR_NBR,
POP_TA_RADIUS_CNT, PROJ_POP_GROWTH_5_YRS_PCT, POP_60_PLUS_PCT, POP_PER_SQ_MILE_CNT,
INCOME_DENSITY_AMT, PROJ_HH_GROWTH_5_YRS_PCT, PER_CAPITA_INCOME_AMT, MEDIAN_AGE_NBR,
WHITE_PCT, BLACK_PCT, ASIAN_PCT, OTHER_RACE_PCT, HISP_PCT, RNTRS_PCT,
POP_IN_ARMED_FORCES_PCT, 
-- HOME_VALUE_INDEX_NBR,
URBAN_PCT, SUBURBAN_PCT,
SEC_CITY_PCT, TOWN_AND_RURAL_PCT, DIST_TO_WAG_CNT, DIST_TO_WALM_CNT, DIST_TO_CVS_CNT,
DIST_TO_GROC_W_RX_CNT, DIST_TO_CHAIN_DRUG_CNT, DIST_TO_GROC_CNT, DIST_TO_MAJOR_MASS_CNT, DIST_TO_MINOR_MASS_CNT,
RETL_BUS_CNT, RETL_EMP_CNT, INDUS_BUS_CNT, INDUS_EMP_CNT, TOT_BUS_CNT, TOT_EMP_CNT, COMPAT_BUS_CNT,
COMPAT_EMP_CNT, MEDICAL_BUS_CNT, MEDICAL_EMP_CNT,
case when HOSP_BEDS_CNT is null then 0 else HOSP_BEDS_CNT end as HOSP_BEDS_CNT,
EDUC_0_TO_9TH_PCT, EDUC_SOME_HS_PCT, EDUC_HS_GRAD_PCT, EDUC_SOME_COLLEGE_PCT, EDUC_ASSOCIATE_DEGREE_PCT,
EDUC_BACHELOR_DEGREE_PCT, EDUC_GRAD_OR_PROF_DEGREE_PCT,
CVS_CNT,WALM_CNT,TRGT_CNT,KMART_CNT
CHAIN_DRUG_STR_CNT,CHAIN_DRUG_STR_NO_RX_CNT,CHAIN_RX_CNT
GROC_CNT,GROC_PHARM_CNT,WHOLESALE_MBR_CNT,MASS_MERCH_CNT,MINOR_MERCH_CNT,MAJOR_MASS_CNT,INDEP_CNT,
coalesce(COTENANTS_PHARMACY_COUNT,0) as COTENANTS_PHARMACY_COUNT,
coalesce(COTENANTS_RESTAURANT_COUNT,0) as COTENANTS_RESTAURANT_COUNT,
coalesce(COTENANTS_RESTAURANT___QUICK_SERVICE_COUNT,0) as COTENANTS_RESTAURANT_QUICK_SERVICE_COUNT,
coalesce(COTENANTS_RESTAURANT___SNACK_COUNT,0) as COTENANTS_RESTAURANT_SNACK_COUNT,
coalesce(COTENANTS_CELLULAR___PAGING_COUNT,0) as COTENANTS_CELLULAR_PAGING_COUNT,
coalesce(COTENANTS_APPAREL_COUNT,0) as COTENANTS_APPAREL_COUNT,
coalesce(COTENANTS_VIDEO_SALES___RENTAL_COUNT,0) as COTENANTS_VIDEO_SALES_RENTAL_COUNT,
coalesce(COTENANTS_OFFICE_SUPPLY_COUNT,0) as COTENANTS_OFFICE_SUPPLY_COUNT, 
coalesce(COTENANTS_SUPERMARKET_COUNT,0) as COTENANTS_SUPERMARKET_COUNT,
coalesce(COTENANTS_RESTAURANT___CASUAL_DINING_COUNT,0) as COTENANTS_RESTAURANT_CASUAL_DINING_COUNT,
coalesce(COTENANTS_VITAMIN___HEALTH_COUNT,0) as COTENANTS_VITAMIN_HEALTH_COUNT,
coalesce(COTENANTS_HAIR_CARE_COUNT,0) as COTENANTS_HAIR_CARE_COUNT,
coalesce(COTENANTS_OPTICAL___OPTICIAN_COUNT,0) as COTENANTS_OPTICAL_OPTICIAN_COUNT,
coalesce(COTENANTS_RESTAURANT___QUICK_CASUAL_COUNT,0) as COTENANTS_RESTAURANT_QUICK_CASUAL_COUNT,
coalesce(COTENANTS_COSMETICS___HBA_COUNT,0) as COTENANTS_COSMETICS_HBA_COUNT, 
coalesce(COTENANTS_DOLLAR_STORE_COUNT,0) as COTENANTS_DOLLAR_STORE_COUNT,
coalesce(COTENANTS_EDUCATION_COUNT,0) as COTENANTS_EDUCATION_COUNT,
coalesce(COTENANTS_DISCOUNT_STORE_COUNT,0) as COTENANTS_DISCOUNT_STORE_COUNT,
coalesce(COTENANTS_HEALTH_AND_FITNESS_CLUBS_COUNT,0) as COTENANTS_HEALTH_AND_FITNESS_CLUBS_COUNT,
cast("2024 Average Apparel and services" as float) as Apparel_and_services_spend,
cast("2024 Average Cash contributions" as float) as Cash_contributions_spend ,
cast("2024 Average Education" as float) as education_spend,	
cast("2024 Average Entertainment" as float) as entertainment_spend,	
cast("2024 Average Food" as float) as Food_spend,
cast("2024 Average Housing" as float) as Housing_spend	,
cast("2024 Average Personal care products and services" as float) as Personal_care_products_and_services_Spend,	
cast("2024 Average Personal insurance and pensions" as float) as Personal_insurance_and_pensions_spend ,
cast("2024 Average Reading" as float) as Reading_spend,
cast("2024 Average Transportation" as float) as Transportation_spend
from 
DL_FSCA_SLFSRV.TWA07.MACRO_YEARLY_POG_SALES_DETAILS2  a
left join  DL_FSCA_SLFSRV.TWA07.c830557_localization_store_demographics_master_table b
on a.store_nbr = b.str_nbr
left join DL_FSCA_SLFSRV.TWA07.c830557_localization_external_cotenants_agg_data c on a.store_nbr=c.store_nbr
left join store_details_full d on a.store_nbr=d.str_nbr
left join DL_FSCA_SLFSRV.TWA07.C830557_LOCALIZATION_EXTERNAL_GEO_DATA e on a.store_nbr=e.store_nbr;



create or replace table DL_FSCA_SLFSRV.TWA07.MACRO_PREDICTIVE_MODEL_TABLE2 as 
select * from DL_FSCA_SLFSRV.TWA07.MACRO_PREDICTIVE_MODEL_TABLE
where store_nbr not in (4615, 1967, 2064, 2280, 2433, 2437, 2724, 464, 478, 509, 867, 955, 1084, 1113, 1220, 1243, 10289, 5855, 5980, 7400, 8940, 8969, 9106, 9107, 3121, 3226, 3236, 3250, 3296, 3315, 3327, 3351, 3401, 3443, 3570, 3610, 3650, 3655, 3704, 3705, 3706, 3722, 3737, 3756, 3811, 3921, 3956, 4032, 4072, 4701, 5010, 5040, 5041, 5118, 5127, 5136, 5147, 5154, 5233, 113, 2379, 402, 476, 536, 538, 554, 564, 2897, 591, 637, 866, 925, 931, 932, 976, 981, 1126, 1127, 1136, 5783, 5924, 6002, 6732, 7131, 7133, 7897, 7973, 8000, 8378, 10915, 3153, 3986, 4019, 4065, 4789, 4792, 5022, 5499, 2768, 2944, 2963, 3033, 3056, 3061, 3078, 10807, 5775, 5792, 5834, 5841, 5945, 6755, 6772, 7001, 7088, 7127, 7860, 8439, 8778, 8781, 8800, 8803, 8808, 8819, 8824, 8825, 8831, 8840, 8841, 8849, 8854, 8855, 8857, 8858, 8859, 8860, 8865, 8867, 8870, 8874, 8875, 8889, 8892, 8897, 8898, 8943, 9104, 9108, 9115, 9121, 9122, 9123, 9138, 9140, 9151, 9186, 9193, 9196, 9240, 9334, 9349, 9371, 9374, 9377, 9488, 9500, 9501, 9507, 9524, 9557, 9574, 9583, 9588, 9589, 9590, 9594, 9596, 9602, 9604, 9609, 9610, 9617, 9619, 9625, 9626, 9629, 9634, 9636, 9637, 9639, 9642, 9651, 9654, 9664, 9665, 9666, 9672, 9673, 9687, 9690, 9695, 9708, 9728, 9735, 9738, 9745, 9750, 9757, 9762, 9771, 9780, 9782, 9783, 9792, 9794, 9796, 9821, 9837, 9845, 9848, 9850, 9857, 9861, 9866, 9871, 9900, 11073, 10931, 1533, 3178, 3693, 4356, 4706, 4732, 4820, 5260, 2701, 213, 1057, 1201, 10412, 10446, 10449, 10485, 5651, 5657, 5857, 5858, 5959, 5970, 5981, 6241, 6665, 6716, 6741, 6742, 6776, 6781, 6786, 6803, 6824, 6847, 6865, 6895, 6979, 6991, 7106, 7149, 7193, 7222, 7231, 7287, 7299, 7306, 7319, 7373, 7403, 7421, 7456, 7664, 7679, 7741, 7748, 7784, 7831, 8389, 10638, 8912, 8962, 8963, 10051, 10073, 10142, 10148, 10215, 10217, 10227, 10946)
and planogram_nbr in (9640, 9700, 9370, 9523, 9140, 9240, 9500, 9281, 9280, 9136, 9260, 9380, 9728, 9576, 9041, 9406, 9255, 9200, 9210, 9600, 9584, 9616, 9360, 9617, 9090, 9569, 9400, 9378, 9350, 9608, 9340, 9615, 9403, 9751, 9770, 9150, 9330, 9145, 9425, 9605, 9531, 9582, 9631, 9010, 9570, 9367, 9895, 9285, 9232, 9020, 9470, 9040, 9035, 9030, 9061, 9544, 9060, 9542, 9571, 9171, 9683, 9680, 9236, 9302, 9410, 9623, 9270, 9822, 9211, 9300, 9242, 9918, 7700, 9080, 9428, 9398, 9224, 9601, 9371, 9062, 9401, 9475, 9690, 9620, 9537, 9543, 3920);


--C830557_LOCALIZATION_EXTERNAL_GEO_DATA was directly loaded to snowflake from kubeflow