select * from DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
where PLANOGRAM_DSC = '{dept_name}' 