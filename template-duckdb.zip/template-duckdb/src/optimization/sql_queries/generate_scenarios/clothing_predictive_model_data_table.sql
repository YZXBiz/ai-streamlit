SELECT
  *
FROM
  MKT_DB.STG_MERCHANDISE.SPACE_OPT_clothing_predictive_model_data_table
WHERE
    RUN_DATE_TIME = (
        SELECT MAX(RUN_DATE_TIME)
        FROM MKT_DB.STG_MERCHANDISE.SPACE_OPT_clothing_predictive_model_data_table
    )
  AND YEAR = (
        SELECT MAX(YEAR)
        FROM MKT_DB.STG_MERCHANDISE.SPACE_OPT_clothing_predictive_model_data_table
    );
