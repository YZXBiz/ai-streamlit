WITH Filtered_space_sales AS (
    SELECT
        STORE_NO,
        pog_cat,
        pog_dept,
        YEAR,
        TOTAL_ALLOC_SALES_AMT,
        TOTAL_ALLOC_COST_AMT,
        AVG_POG_SQFT
    FROM
        MKT_DB.STG_MERCHANDISE.SPACE_OPT_pog_cat_annual_space_sales
    WHERE
        RUN_DATE_TIME = (
            SELECT MAX(RUN_DATE_TIME)
            FROM MKT_DB.STG_MERCHANDISE.SPACE_OPT_pog_cat_annual_space_sales
        )
),
Filtered_gran AS (
    SELECT
        pog_cat,
        pog_dept,
        POG_HYBRID_DESC,
    FROM
        MKT_DB.STG_MERCHANDISE.SPACE_OPT_pog_granularity
    WHERE
        RUN_DATE_TIME = (
            SELECT MAX(RUN_DATE_TIME)
            FROM MKT_DB.STG_MERCHANDISE.SPACE_OPT_pog_granularity
        )
)
SELECT
    space_sales.STORE_NO,
    space_sales.pog_cat,
    space_sales.pog_dept,
    gran.POG_HYBRID_DESC,
    space_sales.TOTAL_ALLOC_SALES_AMT AS LY_SALES,
    space_sales.TOTAL_ALLOC_SALES_AMT - space_sales.TOTAL_ALLOC_COST_AMT AS LY_PROFIT,
    space_sales.AVG_POG_SQFT AS LY_SPACE
FROM
    Filtered_space_sales space_sales
JOIN
    Filtered_gran gran
ON
    gran.pog_cat = space_sales.pog_cat
    AND gran.pog_dept = space_sales.pog_dept
WHERE
    space_sales.YEAR = (
        SELECT MAX(YEAR)
        FROM MKT_DB.STG_MERCHANDISE.SPACE_OPT_pog_cat_annual_space_sales
    );