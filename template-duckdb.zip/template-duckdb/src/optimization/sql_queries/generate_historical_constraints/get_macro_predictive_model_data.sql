SELECT store_nbr, plano_cat_dsc, planogram_dsc, total_margin, total_sales,
       fixture_width_nbr, fixture_height_nbr, st_cd
       FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
       where year=2024;
