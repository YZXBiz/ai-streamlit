create or replace table DL_FSCA_SLFSRV.TWA07.c830557_macro_pog_sizes_test as


with seasonal_sizes as (
select 
a.plano_cat_dsc,a.planogram_dsc,fixture_width_nbr, a.store_count,  total_stores, store_count/total_stores as pct_stores
from 
(select 'SEASONAL' as plano_cat_dsc, 'SEASONAL' as planogram_dsc, 
case when fixt_length_ft<4 then 4
else floor((fixt_length_ft+3.9999999)/4)*4 end as fixture_width_nbr,
count(distinct store_nbr) as store_count
from DL_FSCA_SLFSRV.TWA07.C830557_SEASONAL
where plano_nbr='3920-001'
group by 1,2,3
order by 1,2,3) a 
left join (select 'SEASONAL' as planogram_dsc, count(distinct store_nbr) as total_stores from DL_FSCA_SLFSRV.TWA07.C830557_SEASONAL
where plano_nbr='3920-001'
group by 1) using (planogram_dsc)
),

remaining_pog_sizes as (
select 
a.plano_cat_dsc,a.planogram_dsc,fixture_width_nbr, a.store_count,  total_stores, store_count/total_stores as pct_stores
from
(select plano_cat_dsc,planogram_dsc, fixture_width_nbr/(fixture_height_nbr/60) as fixture_width_nbr, count(distinct store_nbr) as store_count
from DL_FSCA_SLFSRV.TWA07.c830557_macro_monthly_pog_table 
where load_year_month='2025-01'
and section_width_id='4'
group by 1,2,3) a 
left join  
(select planogram_dsc, count(distinct store_nbr) as total_stores  
from DL_FSCA_SLFSRV.TWA07.c830557_macro_monthly_pog_table 
where load_year_month='2025-01'
and section_width_id='4' group by 1) b
using (planogram_dsc)
order by 1,2,3
)

select * from remaining_pog_sizes
union
select * from seasonal_sizes;