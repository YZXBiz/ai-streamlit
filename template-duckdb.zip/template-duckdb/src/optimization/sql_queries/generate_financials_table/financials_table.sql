CREATE OR REPLACE TABLE DL_FSCA_SLFSRV.TWA07.MACRO_MONTHLY_FINANCIALS AS
 
WITH financials AS (
    SELECT
        aa.*
    FROM "CORE_FS"."CURATED_SALES"."TRANSACTION_DETAIL" AA
    JOIN CORE_FSSC.CURATED_CALENDAR.DAY cal 
        ON cal.DATE_DT = DATE(AA.TXN_DATETIME)
    JOIN core_fssc.curated_product.sku sku 
        ON sku.sku_nbr = aa.sku_nbr
    JOIN PROD_COMM_DB.CDP_APP.STORE str 
        ON aa.store_nbr = str.STORE_NBR
    JOIN (
        SELECT DISTINCT 
            sku_nbr,
            store_nbr,
            fiscal_week_nbr,
            price_zone_nbr
        FROM APP_MERCH.PROD_PROMO.WKLY_SKU_STR_FEATURES
    ) str_pz 
        ON str_pz.store_nbr = str.store_nbr
        AND str_pz.sku_nbr = aa.sku_nbr
        AND cal.fiscal_week_nbr = str_pz.fiscal_week_nbr
    WHERE 
        AA.TXN_ITEM_TYPE_CD IN (1)
        AND AA.EVENT_TYPE_CD IN (
            '0', '1', '2', '3', '4', '5', '6', '9', 'C', 'J', 'K', 
            'L', 'S', 'W', 'Y', 'Q', 'R', 'T', 'U'
        )
        AND aa.scan_qty > 0
        AND aa.store_nbr < 16000 
        AND cal.fiscal_week_nbr > 202201
        AND str.AD_RGN_CD NOT IN ('F', 'W', '999')
        AND state NOT IN ('HI', 'PR')
)
 
SELECT 
    TO_CHAR(txn_datetime, 'YYYY-MM') AS load_year_month,
    store_nbr, 
    sku_nbr, 
    SUM(scan_qty) AS total_sold_qty,
    SUM(extnd_scan_amt) AS total_sales,
    SUM(extnd_cost_amt) AS total_cost,
    SUM(extnd_scan_amt) - SUM(extnd_cost_amt) AS total_margin
FROM financials
GROUP BY 1, 2, 3;