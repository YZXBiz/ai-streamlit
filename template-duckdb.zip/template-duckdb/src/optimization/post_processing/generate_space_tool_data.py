import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from util import utils
 
def load_optimizer_data(optimizer_output_table, planogram_metadata_df):
    opt_output = utils.read_table(f"SELECT * FROM {optimizer_output_table}")
    mdse = planogram_metadata_df.copy()
    mdse["Dept"] = "_" + mdse['PLANO_CAT_DSC'] + "_" + mdse["PLANOGRAM_DSC"]
    opt_output = opt_output.merge(mdse, on='Dept', how='left')
 
    opt_output['current_space_norm'] = opt_output['current_space']
    opt_output['current_space'] = opt_output['current_space'] / (opt_output['current_height'] / 60)
    opt_output['dept_allotted_space_norm'] = opt_output['dept_allotted_space']
    opt_output['dept_allotted_space'] = opt_output['dept_allotted_space'] / (opt_output['current_height'] / 60)
 
    opt_output['incremental_space'] = opt_output['dept_allotted_space'] - opt_output['current_space']
    opt_output['pct_space_change'] = opt_output['incremental_space'] / opt_output['current_space']
    opt_output['pct_sales_change'] = opt_output['incremental_sales'] / opt_output['LY_forecasted_sales']
    opt_output['hitting_max_limit'] = np.where(np.abs(opt_output['dept_allotted_space'] - opt_output['dept_size_max']) < 1, 1, 0)
    opt_output['hitting_min_limit'] = np.where(np.abs(opt_output['dept_allotted_space'] - opt_output['dept_size_min']) < 1, 1, 0)
    opt_output['hitting_min_limit'] = np.where(opt_output['hitting_max_limit'] == 1, 0, opt_output['hitting_min_limit'])
 
    return opt_output
 
def compute_productivity_tables(opt_output):
    opt_output['Sales_Productivity'] = opt_output['LY_SALES'] / opt_output['current_space_norm']
    opt_output['Margin_Productivity'] = opt_output['LY_MARGIN'] / opt_output['current_space_norm']
    opt_output['Wt_Sales_Productivity'] = opt_output['Sales_Productivity'] * opt_output['LY_SALES']
    opt_output['Wt_Margin_Productivity'] = opt_output['Margin_Productivity'] * opt_output['LY_MARGIN']
 
    prod_agg = opt_output.groupby(
        ['Store','PLANO_MDSE_GRP_DSC','PLANO_CAT_DSC','PLANOGRAM_DSC','PLANOGRAM_NBR']
    )[['Wt_Sales_Productivity','Wt_Margin_Productivity','LY_SALES','LY_MARGIN','current_space_norm']].sum().reset_index()
 
    prod_agg['Wt_Sales_Productivity'] = prod_agg['Wt_Sales_Productivity'] / prod_agg['LY_SALES']
    prod_agg['Wt_Margin_Productivity'] = prod_agg['Wt_Margin_Productivity'] / prod_agg['LY_SALES']
 
    overall_productivity = pd.DataFrame({
        "Wt_Sales_Productivity_10pct": [prod_agg["Wt_Sales_Productivity"].quantile(0.1)],
        "Wt_Sales_Productivity_median": [prod_agg["Wt_Sales_Productivity"].median()],
        "Wt_Sales_Productivity_90pct": [prod_agg["Wt_Sales_Productivity"].quantile(0.9)],
        "Wt_Margin_Productivity_10pct": [prod_agg["Wt_Margin_Productivity"].quantile(0.1)],
        "Wt_Margin_Productivity_median": [prod_agg["Wt_Margin_Productivity"].median()],
        "Wt_Margin_Productivity_90pct": [prod_agg["Wt_Margin_Productivity"].quantile(0.9)],
    })
 
    return prod_agg, overall_productivity
 
def aggregate_space_output(opt_output, group_cols):
    return opt_output.groupby(group_cols).agg({
        'LY_forecasted_sales':'sum',
        'LY_forecasted_margin':'sum',
        'forecasted_sales':'sum',
        'forecasted_margin':'sum',
        'LY_SALES':'sum',
        'LY_MARGIN':'sum',
        'incremental_sales':'sum',
        'incremental_margin':'sum',
        'current_space':'sum',
        'dept_allotted_space':'sum',
        'incremental_space':'sum',
        'current_space_norm':'sum',
        'dept_allotted_space_norm':'sum',
        'Store':'nunique',
        'hitting_max_limit':'sum',
        'hitting_min_limit':'sum'
    }).reset_index()
 
def apply_conditional_formatting(workbook, sheet_name, df, overall_row, columns):
    ws = workbook[sheet_name]
    green_fill = PatternFill(start_color="EBF1DE", end_color="EBF1DE", fill_type="solid")
    red_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
    col_indexes = {col: df.columns.get_loc(col) + 1 for col in columns}
 
    for row_idx, row in enumerate(df.itertuples(index=False), start=2):
        for col_name, col_idx in col_indexes.items():
            cell = ws.cell(row=row_idx, column=col_idx)
            reference = overall_row[col_name]
            value = getattr(row, col_name)
            cell.fill = green_fill if value > reference else red_fill
 
 
def generate_space_tool_data(
    optimizer_output_table: str,
    output_dir: str,
    run_date_time: str
):
    
    planogram_metadata_df = utils.read_table("""
    SELECT DISTINCT planogram_nbr, planogram_dsc, plano_cat_dsc, plano_mdse_grp_dsc
    FROM DL_FSCA_SLFSRV.TWA07.c830557_macro_predictive_model_table2
    WHERE year = 2024
    """)
    
    # Load data
    opt_output = load_optimizer_data(optimizer_output_table, planogram_metadata_df)
 
    # Aggregations
    agg1 = aggregate_space_output(opt_output, ['PLANO_MDSE_GRP_DSC','PLANO_CAT_DSC'])
    agg2 = aggregate_space_output(opt_output, ['PLANO_MDSE_GRP_DSC','PLANO_CAT_DSC','PLANOGRAM_DSC','PLANOGRAM_NBR'])
    agg3 = aggregate_space_output(opt_output, ['PLANO_MDSE_GRP_DSC'])
 
    # Productivity
    prod_agg, overall_prod = compute_productivity_tables(opt_output)
 
    # Save to Excel
    output_file = f"{output_dir}/space_tool_output.xlsx"
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        opt_output.to_excel(writer, sheet_name='raw', index=False)
        agg1.to_excel(writer, sheet_name='pog_cat_results', index=False)
        agg2.to_excel(writer, sheet_name='pog_results', index=False)
        agg3.to_excel(writer, sheet_name='mdse_results', index=False)
        prod_agg.to_excel(writer, sheet_name='pog_productivity', index=False)
        overall_prod.to_excel(writer, sheet_name='overall_productivity', index=False)
 
    # Apply formatting
    # wb = load_workbook(output_file)
    # overall_row = overall_prod.iloc[0]
    # apply_conditional_formatting(wb, 'pog_productivity', prod_agg, overall_row, [
        # "Wt_Sales_Productivity_10pct", "Wt_Sales_Productivity_median", "Wt_Sales_Productivity_90pct",
        # "Wt_Margin_Productivity_10pct", "Wt_Margin_Productivity_median", "Wt_Margin_Productivity_90pct"
    # ])
    # wb.save(output_file)
    print(f"Optimizer output saved here: {output_file}")
