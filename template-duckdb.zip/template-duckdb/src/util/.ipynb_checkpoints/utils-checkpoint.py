####################################################################################################
import json
import re
import os
import logging
from datetime import datetime
from typing import Union, Optional

import pandas as pd

from fsutils import run_sf_sql as rp, config
import yaml
from snowflake.connector.pandas_tools import write_pandas


####################################################################################################


def get_conn():
    """
    Establishes a connection to Snowflake using fsutils.
 
    Returns
    -------
    tuple
        Snowflake connection and cursor objects.
    """
    # Configuration map name for fsutils
    configmapname = "notebook-medium"
 
    # Retrieve connection parameters and create connection
    params = config.get_config(configmapname)
    conn, cur = rp.get_connection(configmapname)
 
    return conn, cur
 

    
def execute_sql_query(query: str) -> None:
    """
    Executes a SQL query in Snowflake.
 
    Parameters
    ----------
    query : str
        The SQL query to execute.
 
    Returns
    -------
    None
    """
    conn, cur = get_conn()
    try:
        print("Executing query...")
        cur.execute(query)
        conn.commit()  # Commit the transaction if necessary
        print("Query executed successfully.")
    except Exception as e:
        print(f"Error executing query: {e}")

 
 


def create_space_opt_dirs(paths: list = None) -> dict:
    """
    Ensures that a list of directory paths exists, creating any that do not.
    Automatically adds today's date in the format YYYYMMDD to each provided path.
    Returns a dictionary where the last component of each original path (before adding the date)
    is the key and the modified path (with the date added) is the value.
    Parameters
    ----------
    paths : list of str, optional
        A list of absolute directory paths to check and create if they do not exist. Default is None.
    Returns
    -------
    dict
        A dictionary with the last component of each original path as the key and the modified path (with the date added) as the value.
    """
    if paths is None:
        paths = []
        
    # Get today's date in YYYYMMDD format
    
    today = datetime.now().strftime("%Y%m%d")
    
    modified_paths = {}
    
    for path in paths:
        
        # Ensure the path is absolute
        if not os.path.isabs(path):
            raise ValueError(f"Provided path '{path}' is not absolute. Please use absolute paths.")
            
        # Append today's date to the path
        dated_path = os.path.join(path, today)
        
        # Create the directory if it does not exist
        
        if not os.path.exists(dated_path):
            os.makedirs(dated_path, exist_ok=True)
            print(f"Created directory: {dated_path}")
            
        else:
            print(f"Directory already exists: {dated_path}")
            
        # Get the last component of the original path (without date)
        
        last_component = os.path.basename(os.path.normpath(path))
        
        modified_paths[last_component] = dated_path
        
    return modified_paths


def create_logger(log_dir: str = None) -> logging.Logger:
    """
    Creates and configures a logger that logs messages to both a file and the console.

    Parameters
    ----------
    log_dir : str
        The directory where log files will be saved. The directory will be created if it does not exist.

    Returns
    -------
    logging.Logger
        The configured logger instance.

    Notes
    -----
    - The log file will be named using the format `YYYYMMDDHHMM.log`, where the filename reflects the timestamp of when the logger was created.
    - The logger will log messages of all levels (DEBUG and above) to the file and error level messages to the console.
    - Any existing handlers of the logger will be removed before adding the new handlers.

    Examples
    --------
    >>> log_directory = "space_opt_outputs/logs/"
    >>> logger = create_logger(log_directory)
    >>> logger.info("This is an info message")
    >>> logger.error("This is an error message")
    """
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Create logger
    logger = logging.getLogger("space_opt_logger")
    logger.setLevel(logging.DEBUG)

    # Remove any existing handlers
    if logger.hasHandlers():
        logger.handlers.clear()

    # Create file handler which logs even debug messages
    current_time = datetime.now().strftime("%Y%m%d%H%M")
    log_filename = os.path.join(log_dir, f"{current_time}.log")

    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG)

    # Create console handler with a higher log level
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.ERROR)

    # Create formatter and add it to the handlers
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger



def load_config(file_path: str) -> dict:
    """
    Loads configuration data from a YAML file.

    Parameters
    ----------
    file_path : str
        The path to the YAML configuration file.

    Returns
    -------
    dict
        A dictionary containing the configuration data loaded from the file.

    Notes
    -----
    - The function uses `yaml.safe_load` to parse the YAML file, ensuring safe loading of the configuration data.
    """
    with open(file_path, "r+") as file:
        config = yaml.safe_load(file)
    return config







def load_sql_query(sql_files_dict: dict = None, exclude_keys: list = None) -> dict:
    """
    Loads SQL queries from specified files and returns a dictionary containing the queries,
    optionally excluding certain keys.

    Parameters
    ----------
    sql_files_dict : dict, optional
        A dictionary where the keys represent identifiers for the SQL queries (e.g., file names),
        and the values are the file paths to the SQL query files. Defaults to None.
    exclude_keys : list, optional
        A list of keys to exclude from the resulting `queries_dict`. These keys correspond to
        the identifiers in `sql_files_dict`. Defaults to None.

    Returns
    -------
    dict
        A dictionary containing the loaded SQL queries. The keys are the identifiers from `sql_files_dict`,
        and the values are the query strings loaded from the files, excluding those specified in `exclude_keys`.

    Examples
    --------
    >>> files = {'query1': 'path/to/query1.sql', 'query2': 'path/to/query2.sql'}
    >>> load_sql_query(files, exclude_keys=['query2'])
    {'query1': 'SELECT * FROM table1;'}
    """
    queries_dict = {}
    for query_file in sql_files_dict.keys():
        if exclude_keys and query_file in exclude_keys:
            continue
        with open(str(sql_files_dict[query_file]), "r+", encoding="utf-8") as f:
            queries_dict[query_file] = f.read()
    return queries_dict



 
def write_to_snowflake(
    df: pd.DataFrame,
    full_table_name: str,
    verbose: bool = True
) -> None:
    """
    Writes a DataFrame to Snowflake using full table name like 'DB.SCHEMA.TABLE',
    with auto table creation and overwrite enabled.
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to write.
    full_table_name : str
        Full target path: 'DB.SCHEMA.TABLE'.
    verbose : bool
        Print progress logs.
    """
    conn, _ = get_conn()
    
    try:
        db, schema, table = full_table_name.split(".")
    except ValueError:
        raise ValueError("Table name must be in format 'DATABASE.SCHEMA.TABLE'")
        
    if verbose:
        print(f"Uploading to Snowflake: {db}.{schema}.{table}")
 
    success, nchunks, nrows, _ = write_pandas(
        conn=conn,
        df=df,
        table_name=table,
        database=db,
        schema=schema,
        overwrite=True,
        auto_create_table=True
    )
 
    if verbose:
        print(f"Upload complete: {nrows} rows written to {db}.{schema}.{table}")

 

 
def read_table(query: str, print_query: bool = False) -> pd.DataFrame:
    """
    Executes a read query and returns results as a pandas DataFrame.
    
    Parameters
    ----------
    query : str
        SQL query to run.
    print_query : bool
        If True, prints the query before executing.
    Returns
    -------
    pd.DataFrame
        Query result.

    """
    conn, cursor = get_conn()
    
    print('Reading data...')
    
    if print_query:
        print(f'\t Query: \n {query}')
    
    df = pd.read_sql(query, conn)
    
    print('Data fetch complete')
    return df
 