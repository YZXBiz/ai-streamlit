from src.util import utils
import os

# Set up Run Time Vars (as done in your main code)
spark = utils.create_spark_session()  # Assuming create_spark_session is already defined in utils
dbutils = utils.create_dbutils(spark)  # Assuming create_dbutils is already defined in utils

# Load the db_config from the YAML file
db_config = utils.load_config("config/db_config.yaml")

# Get options from db_config and dbutils
db_options = utils.get_options(db_config, dbutils)

# Set the db_options as an environment variable
os.environ["db_options"] = db_options

# Simulated query_dict with the SQL query path
query_dict = {
    "productivity_curves_data_table": "optimization/sql_queries/generate_productivity_curves/productivity_curves_data_table.sql"
}

# Load SQL queries from the dictionary
loaded_queries = utils.load_sql_query(query_dict)

# Print the loaded SQL queries
print("Loaded SQL for 'productivity_curves_data_table':")
print(loaded_queries["productivity_curves_data_table"])

# Fetch data from Snowflake using the loaded query
sql_query = loaded_queries["productivity_curves_data_table"]

# Fetch data from Snowflake using the loaded SQL query
data = utils.get_data_from_snowflake(sql_query, convert_to_pd=True)

# Print the fetched data
print("\nFetched Data from Snowflake:")
print(data)