"""
This serves as the main entry point into the space_opt program
"""

###################################### --- Module Imports --- ######################################
import logging
import traceback
import sys
import time
from datetime import datetime
from util import utils


from optimization.data_processing.generate_financials_table import (
    generate_financials_table,
)


from optimization.data_processing.generate_space_table import (
    generate_space_table,
)

from optimization.data_processing.generate_annual_space_sales_table import (
    generate_annual_space_sales_table,
)


from optimization.data_processing.generate_predictive_model_data_table import (
    generate_predictive_model_data_table,
)


from optimization.data_processing.generate_historical_constraints import (
    generate_historical_constraints,
)


from optimization.predictive_modeling.build_predictive_model import (
    build_predictive_model,
)


from optimization.predictive_modeling.generate_scenarios import (
    generate_scenarios_for_prod_curves,
)


from optimization.predictive_modeling.generate_productivity_curves_data import (
    generate_productivity_curves_data,
)


from optimization.predictive_modeling.generate_productivity_curves import (
    generate_productivity_curves,
)


from optimization.optimizer.generate_store_sample import (
    generate_store_sample,
)


from optimization.optimizer.optimize_space import (
    optimize_space,
)


from optimization.post_processing.generate_space_tool_data import (
    generate_space_tool_data,
)


###################################### --- Define Space Opt Pipeline --- ######################################
def space_opt_pipeline(main_config_dict: dict = None, local_path_dict: dict = None):
    logger = logging.getLogger("space_opt_logger")
    print(local_path_dict)

    # Load Task Configurations
    tasks_config = main_config_dict["space_opt_setup"]["tasks"]

    financials_table_config = main_config_dict["data_processing"][
        "generate_financials_table"
    ]

    space_table_config = main_config_dict["data_processing"]["generate_space_table"]

    space_sales_config = main_config_dict["data_processing"][
        "generate_space_sales_table"
    ]

    historical_space_constraints_config = main_config_dict["data_processing"][
        "generate_historical_constraints"
    ]

    build_predictive_model_config = main_config_dict["predictive_modeling"][
        "build_predictive_model"
    ]

    generate_scenarios_config = main_config_dict["predictive_modeling"][
        "generate_scenarios"
    ]

    generate_prod_curves_data_config = main_config_dict["predictive_modeling"][
        "generate_productivity_curves_data"
    ]

    generate_prod_curves_config = main_config_dict["predictive_modeling"][
        "generate_productivity_curves"
    ]

    generate_store_sample_config = main_config_dict["optimization"][
        "generate_store_sample"
    ]

    optimization_config = main_config_dict["optimization"]["optimize_space"]

    post_processing_config = main_config_dict["post_processing"][
        "generate_space_tool_data"
    ]

    # Data Tasks

    # Task 1a: Generate financials table
    if tasks_config.get("generate_financials_table", False):
        # Task 1a: Generate financials table
        logger.info("Starting Task 1a: Generate financials table")
        print("Starting Task 1a: Generate financials table")
        task_start_time = time.time()
        try:
            generate_financials_table(
                query_dict=financials_table_config["input_sql_files"],
                local_path=local_path_dict["data"],
                output_table_name=financials_table_config["output_table_name"],
                save_data=financials_table_config["save_data"],
                save_type=financials_table_config["save_type"],
                save_format=financials_table_config["save_format"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 1a completed successfully")
        except Exception as e:
            logger.error(f"Task 1a failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)
        logger.info(
            f"Task 1a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 1a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    # Task 1b Generate corrected space table
    if tasks_config.get("generate_space_table", False):
        # Task 1b Generate corrected space table
        logger.info("Starting Task 1b Generate space table")
        print("Starting Task 1b Generate space table")
        task_start_time = time.time()
        try:
            generate_space_table(
                query_dict=space_table_config["input_sql_files"],
                local_path=local_path_dict["data"],
                output_table_name=space_table_config["output_table_name"],
                save_data=space_table_config["save_data"],
                save_type=space_table_config["save_type"],
                save_format=space_table_config["save_format"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 1bcompleted successfully")
        except Exception as e:
            logger.error(f"Task 1b failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)
        logger.info(
            f"Task 1b completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 1b completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_annual_space_sales_table", False):
        # Task 1d: Generate space and sales data table
        logger.info("Starting Task 1c: Generate space and sales data table")
        print("Starting Task 1c: Generate space and sales data table")
        task_start_time = time.time()
        try:
            generate_annual_space_sales_table(
                query_dict=space_sales_config["input_sql_files"],
                local_path=local_path_dict["data"],
                output_table_name=space_sales_config["output_table_name"],
                save_data=space_sales_config["save_data"],
                save_type=space_sales_config["save_type"],
                save_format=space_sales_config["save_format"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 1c completed successfully")
        except Exception as e:
            logger.error(f"Task 1c Failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)
        logger.info(
            f"Task 1c completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 1c completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_predictive_model_data_table", False):
        # Task 1d: Generate modeling data table
        logger.info("Starting Task 1d: Generate modeling data table")
        print("Starting Task 1d: Generate modeling data table")
        task_start_time = time.time()
        try:
            generate_predictive_model_data_table(
                query_dict=space_sales_config["input_sql_files"],
                local_path=local_path_dict["data"],
                output_table_name=space_sales_config["output_table_name"],
                save_data=space_sales_config["save_data"],
                save_type=space_sales_config["save_type"],
                save_format=space_sales_config["save_format"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 1d completed successfully")
        except Exception as e:
            logger.error(f"Task 1d Failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)
        logger.info(
            f"Task 1d completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 1d completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_historical_constraints", False):
        logger.info("Starting Task 1e: Generate historical space constraints table")
        print("Starting Task 1e: Generate historical space constraints table")
        task_start_time = time.time()
        try:
            generate_historical_constraints(
                query_dict=historical_space_constraints_config["input_sql_files"],
                outlier_limit=historical_space_constraints_config["outlier_limit"],
                output_table_global_constraints=historical_space_constraints_config[
                    "output_table_global_constraints"
                ],
                output_table_store_constraints=historical_space_constraints_config[
                    "output_table_store_constraints"
                ],
                save_data=historical_space_constraints_config["save_data"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 1e completed successfully")
        except Exception as e:
            logger.error(f"Task 1e failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        duration_minutes = (time.time() - task_start_time) / 60
        logger.info(f"Task 1e completed in {duration_minutes:.2f} minutes")
        print(f"Task 1e completed in {duration_minutes:.2f} minutes")

    if tasks_config.get("build_predictive_model", False):
        logger.info("Starting Task 2a: Build predictive model")
        print("Starting Task 2a: Build predictive model")
        task_start_time = time.time()
        try:
            build_predictive_model(
                departments=build_predictive_model_config["departments"],
                model_output_path=local_path_dict["model_outputs"],
                model_analysis_path=local_path_dict["model_analysis"],
                one_hot_encoder_file_name=build_predictive_model_config[
                    "one_hot_encoder_file_name"
                ],
                model_file_name=build_predictive_model_config["model_file_name"],
                data_type_dict=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["data_type_dict"],
                impute_dict=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["impute_dict"],
                outlier_columns=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["outlier_columns"],
                store_open_date_column=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["store_open_date_column"],
                year_column=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["year_column"],
                flag_columns=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["flag_columns"],
                categorical_columns=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["categorical_columns"],
                model_params_dict=build_predictive_model_config["model_params_dict"],
                model_type=build_predictive_model_config["model_type"],
                split_type=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["data_split_type"],
                split_percentages=build_predictive_model_config[
                    "feature_engineering_parameters"
                ]["model_split_percentages"],
                seed=build_predictive_model_config["feature_engineering_parameters"][
                    "seed"
                ],
            )
            logger.info("Task 2a completed successfully")
        except Exception as e:
            logger.error(f"Task 2a failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        duration_minutes = (time.time() - task_start_time) / 60
        logger.info(f"Task 2a completed in {duration_minutes:.2f} minutes")
        print(f"Task 2a completed in {duration_minutes:.2f} minutes")

    if tasks_config.get("generate_scenarios_for_prod_curves", False):
        logger.info(
            "Starting Task 2b: Generate space scenarios for productivity curves"
        )
        print("Starting Task 2b: Generate space scenarios for productivity curves")
        task_start_time = time.time()
        try:
            generate_scenarios_for_prod_curves(
                departments=generate_scenarios_config["departments"],
                num_options=generate_scenarios_config["space_scenarios_per_dept"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 2b completed successfully")
        except Exception as e:
            logger.error(f"Task 2b failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        logger.info(
            f"Task 2b completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 2b completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_productivity_curves_data", False):
        # Task 2c: Use predictive model and space scenarios to generate productivity curves data
        logger.info("Starting Task 2c: Generate productivity curves data")
        print("Starting Task 2c: Generate productivity curves data")
        task_start_time = time.time()
        try:
            generate_productivity_curves_data(
                departments=generate_prod_curves_data_config["departments"],
                model_output_path=local_path_dict["model_outputs"],
                one_hot_encoder_file_name=generate_prod_curves_data_config[
                    "one_hot_encoder_file_name"
                ],
                model_file_name=generate_prod_curves_data_config["model_file_name"],
                model_type=build_predictive_model_config["model_type"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
                year_to_predict=generate_prod_curves_data_config["year_to_predict"],
            )
            logger.info("Task 2c completed successfully")
        except Exception as e:
            logger.error(f"Task 2c failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        logger.info(
            f"Task 2c completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 2c completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_productivity_curves", False):
        # Task 2d: Generate productivity curves
        logger.info("Starting Task 2d: Generate productivity curves")
        print("Starting Task 2d: Generate productivity curves")
        task_start_time = time.time()
        try:
            generate_productivity_curves(
                departments=generate_prod_curves_config["departments"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
                fit_function=generate_prod_curves_config["fit_function"],
                polynomial_order=generate_prod_curves_config["polynomial_order"],
                plot_output_dir=local_path_dict["productivity_curves"],
                save_data=generate_prod_curves_config["save_data"],
                output_table_name=generate_prod_curves_config["output_table_name"],
            )
            logger.info("Task 2d completed successfully")
        except Exception as e:
            logger.error(f"Task 2d failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        logger.info(
            f"Task 2d completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 2d completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    if tasks_config.get("generate_store_sample", False):
        logger.info("Starting Task 3a: Generate Store Sample")
        print("Starting Task 3a: Generate Store Sample")
        task_start_time = time.time()

        try:
            generate_store_sample(
                sample_percent=generate_store_sample_config["sample_percent"],
                num_buckets=generate_store_sample_config["num_buckets"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Store sample generation completed successfully")
        except Exception as e:
            logger.error(
                f"Store sample generation failed: {e}\n{traceback.format_exc()}"
            )
            sys.exit(1)

        logger.info(
            f"Task 3a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 3a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    # Optimize Space
    if tasks_config.get("optimize_space", False):
        logger.info("Starting Task 3a: Optimize Space Allocation")
        print("Starting Task 3a: Optimize Space Allocation")
        task_start_time = time.time()
        try:
            optimize_space(
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
                stores_in_scope=optimization_config["stores_in_scope"],
            )
            logger.info("Task 3a completed successfully")
        except Exception as e:
            logger.error(f"Task 3a failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        logger.info(
            f"Task 3a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 3a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )

    # Post Processing
    if tasks_config.get("generate_space_tool_data", False):
        logger.info("Starting Task 4a: Generate Space Tool Data")
        print("Starting Task 4a: Generate Space Tool Data")
        task_start_time = time.time()
        try:
            generate_space_tool_data(
                optimizer_output_table=post_processing_config["optimizer_output_table"],
                output_dir=local_path_dict["optimization_outputs"],
                run_date_time=main_config_dict["space_opt_setup"]["run_date_time"],
            )
            logger.info("Task 4a completed successfully")
        except Exception as e:
            logger.error(f"Task 4a failed: {e}\n{traceback.format_exc()}")
            sys.exit(1)

        logger.info(
            f"Task 4a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )
        print(
            f"Task 4a completed in {(time.time() - task_start_time) / 60:.2f} minutes"
        )


###################################### --- Main Execution --- ######################################
if __name__ == "__main__":
    # Set up Run Time Vars:
    optimization_config = utils.load_config("config/optimization_config.yaml")

    # Add run id to all dictionaries in config
    run_date_time = datetime.now().strftime("%Y%m%d-%H%M")
    optimization_config["space_opt_setup"]["run_date_time"] = run_date_time

    # Check and create output directories if needed:
    space_opt_out_paths = utils.create_space_opt_dirs(
        optimization_config["space_opt_setup"]["space_opt_output_directories"]
    )

    # Set up the logger:
    log_directory = space_opt_out_paths["logs"]
    logger = utils.create_logger(
        log_directory
    )  # Creates a logger called space_opt_logger

    # Run Pipeline Function:
    logger.info("Starting space optimization pipeline")
    space_opt_pipeline(
        main_config_dict=optimization_config,
        local_path_dict=space_opt_out_paths,
    )
    logger.info("Finished macro space optimization pipeline")
